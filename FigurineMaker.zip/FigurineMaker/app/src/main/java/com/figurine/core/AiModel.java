package com.figurine.core;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Модель от нейросети (файл GLB): чтение, поворот «на ноги», подставка и упрощённая копия для превью.
 */
public final class AiModel {
    private AiModel() {}

    // ------------------------------------------------------------------ GLB

    /** Читает все треугольные сетки из GLB в одну сетку (координаты glTF: Y вверх). */
    @SuppressWarnings("unchecked")
    public static Mesh readGlb(byte[] glb) {
        ByteBuffer bb = ByteBuffer.wrap(glb).order(ByteOrder.LITTLE_ENDIAN);
        if (glb.length < 20 || bb.getInt(0) != 0x46546C67) throw new IllegalArgumentException("Это не GLB-файл");
        int len = Math.min(bb.getInt(8), glb.length);
        int off = 12;
        String json = null;
        int binOff = -1, binLen = 0;
        while (off + 8 <= len) {
            int clen = bb.getInt(off), ctype = bb.getInt(off + 4);
            if (ctype == 0x4E4F534A) json = new String(glb, off + 8, clen, StandardCharsets.UTF_8);
            else if (ctype == 0x004E4942) { binOff = off + 8; binLen = clen; }
            off += 8 + clen;
        }
        if (json == null || binOff < 0) throw new IllegalArgumentException("В GLB нет геометрии");
        Map<String, Object> root = (Map<String, Object>) new Json(json).value();
        List<Object> accessors = (List<Object>) root.get("accessors");
        List<Object> views = (List<Object>) root.get("bufferViews");
        List<Object> meshes = (List<Object>) root.get("meshes");
        if (accessors == null || views == null || meshes == null) throw new IllegalArgumentException("В GLB нет сеток");

        ArrayList<double[]> vs = new ArrayList<>();
        ArrayList<int[]> ts = new ArrayList<>();
        int nvTotal = 0, ntTotal = 0;
        for (Object mo : meshes) {
            List<Object> prims = (List<Object>) ((Map<String, Object>) mo).get("primitives");
            if (prims == null) continue;
            for (Object po : prims) {
                Map<String, Object> p = (Map<String, Object>) po;
                Object mode = p.get("mode");
                if (mode != null && num(mode) != 4) continue;           // только треугольники
                Map<String, Object> attrs = (Map<String, Object>) p.get("attributes");
                if (attrs == null || attrs.get("POSITION") == null) continue;
                double[] pos = floats(accessors, views, bb, binOff, (int) num(attrs.get("POSITION")));
                int n = pos.length / 3;
                int[] idx;
                if (p.get("indices") != null) idx = ints(accessors, views, bb, binOff, (int) num(p.get("indices")));
                else { idx = new int[n]; for (int i = 0; i < n; i++) idx[i] = i; }
                for (int i = 0; i < idx.length; i++) idx[i] += nvTotal;
                vs.add(pos);
                ts.add(idx);
                nvTotal += n;
                ntTotal += idx.length / 3;
            }
        }
        if (nvTotal == 0) throw new IllegalArgumentException("Пустая модель");
        double[] v = new double[nvTotal * 3];
        int[] t = new int[ntTotal * 3];
        int a = 0, b = 0;
        for (double[] x : vs) { System.arraycopy(x, 0, v, a, x.length); a += x.length; }
        for (int[] x : ts) { System.arraycopy(x, 0, t, b, x.length - x.length % 3); b += x.length - x.length % 3; }
        return new Mesh(v, t, 0xF2F2F2, "Фигурка");
    }

    @SuppressWarnings("unchecked")
    private static double[] floats(List<Object> acc, List<Object> views, ByteBuffer bb, int bin, int i) {
        Map<String, Object> a = (Map<String, Object>) acc.get(i);
        int count = (int) num(a.get("count"));
        int comp = (int) num(a.get("componentType"));
        if (comp != 5126) throw new IllegalArgumentException("Координаты не float");
        Map<String, Object> v = (Map<String, Object>) views.get((int) num(a.get("bufferView")));
        int base = bin + (int) num(v.getOrDefault("byteOffset", 0.0)) + (int) num(a.getOrDefault("byteOffset", 0.0));
        int stride = v.get("byteStride") != null ? (int) num(v.get("byteStride")) : 12;
        double[] out = new double[count * 3];
        for (int k = 0; k < count; k++)
            for (int c = 0; c < 3; c++) out[k * 3 + c] = bb.getFloat(base + k * stride + c * 4);
        return out;
    }

    @SuppressWarnings("unchecked")
    private static int[] ints(List<Object> acc, List<Object> views, ByteBuffer bb, int bin, int i) {
        Map<String, Object> a = (Map<String, Object>) acc.get(i);
        int count = (int) num(a.get("count"));
        int comp = (int) num(a.get("componentType"));
        Map<String, Object> v = (Map<String, Object>) views.get((int) num(a.get("bufferView")));
        int base = bin + (int) num(v.getOrDefault("byteOffset", 0.0)) + (int) num(a.getOrDefault("byteOffset", 0.0));
        int[] out = new int[count];
        for (int k = 0; k < count; k++) {
            switch (comp) {
                case 5121: out[k] = bb.get(base + k) & 0xFF; break;
                case 5123: out[k] = bb.getShort(base + k * 2) & 0xFFFF; break;
                case 5125: out[k] = bb.getInt(base + k * 4); break;
                default: throw new IllegalArgumentException("Неизвестный тип индексов " + comp);
            }
        }
        return out;
    }

    private static double num(Object o) { return ((Number) o).doubleValue(); }

    // ---------------------------------------------------------- подготовка

    /**
     * glTF (Y вверх, лицом к +Z) → наша система (Z вверх, лицом к −Y); масштаб — большая сторона sizeMm;
     * низ на Z=0, по центру. Возвращает [фигурка, подставка].
     */
    public static List<Mesh> standing(Mesh m, double sizeMm, int color) {
        double[] v = new double[m.v.length];
        for (int i = 0; i < v.length; i += 3) {
            v[i] = m.v[i];
            v[i + 1] = -m.v[i + 2];
            v[i + 2] = m.v[i + 1];
        }
        double[] lo = {1e30, 1e30, 1e30}, hi = {-1e30, -1e30, -1e30};
        for (int i = 0; i < v.length; i += 3)
            for (int c = 0; c < 3; c++) { lo[c] = Math.min(lo[c], v[i + c]); hi[c] = Math.max(hi[c], v[i + c]); }
        double ext = Math.max(hi[0] - lo[0], Math.max(hi[1] - lo[1], hi[2] - lo[2]));
        double s = ext > 0 ? sizeMm / ext : 1;
        double cx = (lo[0] + hi[0]) / 2, cy = (lo[1] + hi[1]) / 2;
        for (int i = 0; i < v.length; i += 3) {
            v[i] = (v[i] - cx) * s;
            v[i + 1] = (v[i + 1] - cy) * s;
            v[i + 2] = (v[i + 2] - lo[2]) * s;
        }
        Mesh fig = new Mesh(v, m.t, color, "Фигурка");
        double w = (hi[0] - lo[0]) * s, d = (hi[1] - lo[1]) * s;
        double baseH = 3.0, pad = 3.0;
        Figure.Part base = new Figure.Part(Shapes.BOX, "Подставка", 0, 0, 0.6 - baseH / 2,
                w + 2 * pad, d + 2 * pad, baseH, color);
        ArrayList<Mesh> out = new ArrayList<>();
        out.add(fig);
        out.add(Figure.buildPart(base, 8));
        return out;
    }

    /**
     * Упрощение для превью (слияние вершин по сетке grid³): у нейросетевых моделей сотни тысяч
     * треугольников, а телефону для вращения хватает нескольких десятков тысяч.
     */
    public static Mesh simplify(Mesh m, int grid) {
        double[] lo = {1e30, 1e30, 1e30}, hi = {-1e30, -1e30, -1e30};
        for (int i = 0; i < m.v.length; i += 3)
            for (int c = 0; c < 3; c++) { lo[c] = Math.min(lo[c], m.v[i + c]); hi[c] = Math.max(hi[c], m.v[i + c]); }
        double ext = Math.max(hi[0] - lo[0], Math.max(hi[1] - lo[1], hi[2] - lo[2]));
        if (ext <= 0) return m;
        double cell = ext / grid;
        HashMap<Long, Integer> idOf = new HashMap<>();
        ArrayList<double[]> sums = new ArrayList<>();
        int nv = m.v.length / 3;
        int[] map = new int[nv];
        for (int i = 0; i < nv; i++) {
            long gx = (long) ((m.v[i * 3] - lo[0]) / cell), gy = (long) ((m.v[i * 3 + 1] - lo[1]) / cell), gz = (long) ((m.v[i * 3 + 2] - lo[2]) / cell);
            long key = (gx * 4096 + gy) * 4096 + gz;
            Integer id = idOf.get(key);
            if (id == null) { id = sums.size(); idOf.put(key, id); sums.add(new double[4]); }
            double[] s = sums.get(id);
            s[0] += m.v[i * 3]; s[1] += m.v[i * 3 + 1]; s[2] += m.v[i * 3 + 2]; s[3]++;
            map[i] = id;
        }
        double[] v = new double[sums.size() * 3];
        for (int i = 0; i < sums.size(); i++) {
            double[] s = sums.get(i);
            v[i * 3] = s[0] / s[3]; v[i * 3 + 1] = s[1] / s[3]; v[i * 3 + 2] = s[2] / s[3];
        }
        int[] t = new int[m.t.length];
        int n = 0;
        java.util.HashSet<Long> seen = new java.util.HashSet<>();
        for (int i = 0; i < m.t.length; i += 3) {
            int a = map[m.t[i]], b = map[m.t[i + 1]], c = map[m.t[i + 2]];
            if (a == b || b == c || a == c) continue;
            // один и тот же треугольник дважды не нужен
            int x = Math.min(a, Math.min(b, c)), z = Math.max(a, Math.max(b, c)), y = a + b + c - x - z;
            long key = ((long) x * 2000003L + y) * 2000003L + z;
            if (!seen.add(key)) continue;
            t[n++] = a; t[n++] = b; t[n++] = c;
        }
        return new Mesh(v, java.util.Arrays.copyOf(t, n), m.color, m.name);
    }

    // ------------------------------------------------- маленький разбор JSON

    static final class Json {
        private final String s;
        private int p;

        Json(String s) { this.s = s; }

        Object value() {
            ws();
            char c = s.charAt(p);
            if (c == '{') return obj();
            if (c == '[') return arr();
            if (c == '"') return str();
            if (s.startsWith("true", p)) { p += 4; return Boolean.TRUE; }
            if (s.startsWith("false", p)) { p += 5; return Boolean.FALSE; }
            if (s.startsWith("null", p)) { p += 4; return null; }
            int st = p;
            while (p < s.length() && "+-0123456789.eE".indexOf(s.charAt(p)) >= 0) p++;
            return Double.parseDouble(s.substring(st, p));
        }

        private Map<String, Object> obj() {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            p++;
            ws();
            if (s.charAt(p) == '}') { p++; return m; }
            while (true) {
                ws();
                String k = str();
                ws();
                p++;   // :
                m.put(k, value());
                ws();
                char c = s.charAt(p++);
                if (c == '}') return m;
            }
        }

        private List<Object> arr() {
            ArrayList<Object> a = new ArrayList<>();
            p++;
            ws();
            if (s.charAt(p) == ']') { p++; return a; }
            while (true) {
                a.add(value());
                ws();
                char c = s.charAt(p++);
                if (c == ']') return a;
            }
        }

        private String str() {
            StringBuilder b = new StringBuilder();
            p++;
            while (true) {
                char c = s.charAt(p++);
                if (c == '"') return b.toString();
                if (c == '\\') {
                    char e = s.charAt(p++);
                    switch (e) {
                        case 'n': b.append('\n'); break;
                        case 't': b.append('\t'); break;
                        case 'r': b.append('\r'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'u': b.append((char) Integer.parseInt(s.substring(p, p + 4), 16)); p += 4; break;
                        default: b.append(e);
                    }
                } else b.append(c);
            }
        }

        private void ws() { while (p < s.length() && Character.isWhitespace(s.charAt(p))) p++; }
    }
}
