package com.figurine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val KIRI = "com.kiriengine.app"
private const val MAKERLAB = "https://makerworld.com/makerlab/imageto3d"

private fun open(ctx: Context, i: Intent): Boolean = try {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
    true
} catch (e: Exception) {
    false
}

/** Открывает KIRI Engine; если не установлен — его страницу в Google Play. */
private fun openKiri(ctx: Context) {
    val launch = ctx.packageManager.getLaunchIntentForPackage(KIRI)
    if (launch != null && open(ctx, launch)) return
    if (open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$KIRI")))) return
    if (!open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$KIRI"))))
        Toast.makeText(ctx, "Не удалось открыть Google Play", Toast.LENGTH_LONG).show()
}

/** Кнопки «Лучшее качество»: скан по кругу (KIRI Engine) и ИИ по одному фото (MakerLab). */
@Composable
internal fun ScanButtons(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var tips by remember { mutableStateOf(false) }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("Лучшее качество", fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { tips = true }, modifier = Modifier.weight(1f)) {
                Text("Скан по кругу", fontSize = 13.sp)
            }
            OutlinedButton(
                onClick = {
                    if (!open(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(MAKERLAB))))
                        Toast.makeText(ctx, "Не удалось открыть браузер", Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.weight(1f),
            ) { Text("ИИ по одному фото", fontSize = 13.sp) }
        }
    }

    if (tips) {
        AlertDialog(
            onDismissRequest = { tips = false },
            title = { Text("Скан по кругу") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Откроется бесплатное приложение KIRI Engine (режим «Photo Scan»). " +
                            "Оно соберёт настоящую 3D-модель по фото со всех сторон.",
                        fontSize = 14.sp,
                    )
                    Text("Как снимать:", fontSize = 14.sp)
                    Text(
                        "• ровный свет, без бликов и резких теней\n" +
                            "• предмет не двигаем — обходим его сами\n" +
                            "• круг на одной высоте: снимок каждые 10–15° (25–35 фото)\n" +
                            "• второй круг чуть выше, сверху вниз\n" +
                            "• соседние кадры сильно перекрываются, предмет крупно в кадре\n" +
                            "• блестящее и прозрачное сканируется плохо",
                        fontSize = 13.sp,
                    )
                    Text(
                        "Готовую модель экспортируйте в STL или OBJ и откройте в Bambu Studio. " +
                            "Лишний кусок стола срежьте инструментом «Разрезать».",
                        fontSize = 13.sp,
                    )
                }
            },
            confirmButton = { Button(onClick = { tips = false; openKiri(ctx) }) { Text("Открыть KIRI Engine") } },
            dismissButton = { TextButton(onClick = { tips = false }) { Text("Отмена") } },
        )
    }
}
