package com.figurine.core;

import java.util.ArrayList;

/**
 * Единичные примитивы. Рамка габаритов — куб от -0.5 до 0.5 по каждой оси (кроме кольца: по Z ±0.15),
 * ось симметрии — Z. Все сетки замкнутые, нормали наружу (против часовой, если смотреть снаружи).
 */
public final class Shapes {
    public static final int SPHERE = 0, CYLINDER = 1, CONE = 2, BOX = 3, DOME = 4, TORUS = 5;
    public static final String[] NAMES = {"Шар", "Цилиндр", "Конус", "Куб", "Купол", "Кольцо"};

    private Shapes() {}

    /** Плоский буфер, в который складываются вершины и треугольники. */
    private static final class B {
        final ArrayList<double[]> vs = new ArrayList<>();
        final ArrayList<int[]> ts = new ArrayList<>();
        int v(double x, double y, double z) { vs.add(new double[]{x, y, z}); return vs.size() - 1; }
        void tri(int a, int b, int c) { ts.add(new int[]{a, b, c}); }
        /** Четырёхугольник A(лев-верх) B(прав-верх) C(прав-низ) D(лев-низ), если смотреть снаружи. */
        void quad(int a, int b, int c, int d) { tri(a, d, c); tri(a, c, b); }
    }

    /** quality — число сегментов по окружности (минимум 6). Возвращает {double[] вершины, int[] треугольники}. */
    public static Object[] unit(int shape, int quality) {
        int seg = Math.max(6, quality);
        B b = new B();
        switch (shape) {
            case SPHERE: sphere(b, seg, false); break;
            case DOME: sphere(b, seg, true); break;
            case CYLINDER: cylinder(b, seg); break;
            case CONE: cone(b, seg); break;
            case BOX: box(b); break;
            case TORUS: torus(b, seg, Math.max(6, seg / 2)); break;
            default: throw new IllegalArgumentException("shape " + shape);
        }
        double[] v = new double[b.vs.size() * 3];
        for (int i = 0; i < b.vs.size(); i++) {
            double[] p = b.vs.get(i);
            v[i * 3] = p[0]; v[i * 3 + 1] = p[1]; v[i * 3 + 2] = p[2];
        }
        int[] t = new int[b.ts.size() * 3];
        for (int i = 0; i < b.ts.size(); i++) {
            int[] q = b.ts.get(i);
            t[i * 3] = q[0]; t[i * 3 + 1] = q[1]; t[i * 3 + 2] = q[2];
        }
        return new Object[]{v, t};
    }

    private static void sphere(B b, int seg, boolean dome) {
        int rings = Math.max(4, seg / 2);          // шаги по широте от полюса до полюса
        double phiMax = dome ? Math.PI / 2 : Math.PI;
        int top = b.v(0, 0, 0.5);
        int bottom = -1;
        if (!dome) bottom = b.v(0, 0, -0.5);
        // шар: кольца вершин между полюсами; купол: кольца от полюса до экватора включительно
        int nRings = dome ? Math.max(2, rings / 2) : rings - 1;
        int[][] idx = new int[nRings][seg];
        for (int r = 1; r <= nRings; r++) {
            double phi = phiMax * r / (dome ? nRings : rings);
            double z = dome ? (-0.5 + Math.cos(phi)) : 0.5 * Math.cos(phi);
            double rho = 0.5 * Math.sin(phi);
            for (int s = 0; s < seg; s++) {
                double th = 2 * Math.PI * s / seg;
                idx[r - 1][s] = b.v(rho * Math.cos(th), rho * Math.sin(th), z);
            }
        }
        for (int s = 0; s < seg; s++) b.tri(top, idx[0][s], idx[0][(s + 1) % seg]);
        for (int r = 0; r < nRings - 1; r++)
            for (int s = 0; s < seg; s++)
                b.quad(idx[r][s], idx[r][(s + 1) % seg], idx[r + 1][(s + 1) % seg], idx[r + 1][s]);
        if (dome) {
            int c = b.v(0, 0, -0.5);
            for (int s = 0; s < seg; s++) b.tri(c, idx[nRings - 1][(s + 1) % seg], idx[nRings - 1][s]);
        } else {
            for (int s = 0; s < seg; s++) b.tri(bottom, idx[nRings - 1][(s + 1) % seg], idx[nRings - 1][s]);
        }
    }

    private static void cylinder(B b, int seg) {
        int tc = b.v(0, 0, 0.5), bc = b.v(0, 0, -0.5);
        int[] top = new int[seg], bot = new int[seg];
        for (int s = 0; s < seg; s++) {
            double th = 2 * Math.PI * s / seg, x = 0.5 * Math.cos(th), y = 0.5 * Math.sin(th);
            top[s] = b.v(x, y, 0.5);
            bot[s] = b.v(x, y, -0.5);
        }
        for (int s = 0; s < seg; s++) {
            int n = (s + 1) % seg;
            b.quad(top[s], top[n], bot[n], bot[s]);
            b.tri(tc, top[s], top[n]);
            b.tri(bc, bot[n], bot[s]);
        }
    }

    private static void cone(B b, int seg) {
        int apex = b.v(0, 0, 0.5), bc = b.v(0, 0, -0.5);
        int[] ring = new int[seg];
        for (int s = 0; s < seg; s++) {
            double th = 2 * Math.PI * s / seg;
            ring[s] = b.v(0.5 * Math.cos(th), 0.5 * Math.sin(th), -0.5);
        }
        for (int s = 0; s < seg; s++) {
            int n = (s + 1) % seg;
            b.tri(apex, ring[s], ring[n]);
            b.tri(bc, ring[n], ring[s]);
        }
    }

    private static void box(B b) {
        int v0 = b.v(-.5, -.5, -.5), v1 = b.v(.5, -.5, -.5), v2 = b.v(.5, .5, -.5), v3 = b.v(-.5, .5, -.5);
        int v4 = b.v(-.5, -.5, .5), v5 = b.v(.5, -.5, .5), v6 = b.v(.5, .5, .5), v7 = b.v(-.5, .5, .5);
        b.tri(v0, v3, v2); b.tri(v0, v2, v1); // низ
        b.tri(v4, v5, v6); b.tri(v4, v6, v7); // верх
        b.tri(v0, v1, v5); b.tri(v0, v5, v4); // -y
        b.tri(v3, v7, v6); b.tri(v3, v6, v2); // +y
        b.tri(v1, v2, v6); b.tri(v1, v6, v5); // +x
        b.tri(v0, v4, v7); b.tri(v0, v7, v3); // -x
    }

    private static void torus(B b, int ma, int mi) {
        double R = 0.35, r = 0.15;
        int[][] idx = new int[ma][mi];
        for (int i = 0; i < ma; i++) {
            double u = 2 * Math.PI * i / ma;
            for (int j = 0; j < mi; j++) {
                double w = 2 * Math.PI * j / mi;
                double rr = R + r * Math.cos(w);
                idx[i][j] = b.v(rr * Math.cos(u), rr * Math.sin(u), r * Math.sin(w));
            }
        }
        for (int i = 0; i < ma; i++)
            for (int j = 0; j < mi; j++) {
                int a = idx[i][j], bb = idx[(i + 1) % ma][j], c = idx[(i + 1) % ma][(j + 1) % mi], d = idx[i][(j + 1) % mi];
                b.tri(a, bb, c);
                b.tri(a, c, d);
            }
    }
}
