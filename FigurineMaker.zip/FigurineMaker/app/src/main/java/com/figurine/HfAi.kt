package com.figurine

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Бесплатная нейросеть Hunyuan3D-2 (Tencent) на публичном сервере Hugging Face:
 * фото → 3D-форма (GLB). Без ключей и регистрации; у бесплатного сервера есть дневной лимит и очередь.
 */
object HfAi {
    private const val BASE = "https://tencent-hunyuan3d-2.hf.space"

    /** Возвращает GLB-файл модели. Долго (до нескольких минут) — вызывать не в UI-потоке. */
    fun generate(jpeg: ByteArray, status: (String) -> Unit): ByteArray {
        status("Отправляю фото…")
        val path = upload(jpeg)

        val img = JSONObject().put("path", path).put("meta", JSONObject().put("_type", "gradio.FileData"))
        val data = JSONArray()
            .put("")                // текстовая подсказка — не нужна
            .put(img)               // фото
            .put(JSONObject.NULL).put(JSONObject.NULL).put(JSONObject.NULL).put(JSONObject.NULL)  // мульти-ракурсы
            .put(30)                // шаги
            .put(5.0)               // guidance
            .put(1234)              // seed
            .put(256)               // детализация сетки
            .put(true)              // убрать фон
            .put(8000)              // chunks
            .put(true)              // случайный seed
        val c = URL("$BASE/call/shape_generation").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("data", data).toString().toByteArray()) }
        if (c.responseCode != 200) throw IllegalStateException(friendly(c.responseCode, err(c)))
        val eventId = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getString("event_id")

        status("Нейросеть строит модель (обычно 1–3 минуты)…")
        val r = URL("$BASE/call/shape_generation/$eventId").openConnection() as HttpURLConnection
        r.connectTimeout = 30000
        r.readTimeout = 10 * 60 * 1000
        var event = ""
        var result: String? = null
        r.inputStream.bufferedReader().use { rd ->
            while (true) {
                val line = rd.readLine() ?: break
                if (line.startsWith("event:")) event = line.substring(6).trim()
                else if (line.startsWith("data:")) {
                    val d = line.substring(5).trim()
                    when (event) {
                        "complete" -> { result = d; return@use }
                        "error" -> throw IllegalStateException(friendly(0, d))
                    }
                }
            }
        }
        val out = result ?: throw IllegalStateException("Сервер нейросети не ответил, попробуйте ещё раз")
        val arr = JSONArray(out)
        var file = arr.optJSONObject(0) ?: throw IllegalStateException("Нейросеть не вернула модель")
        // сервер заворачивает файл в {"value": {...}, "__type__": "update"}
        file.optJSONObject("value")?.let { file = it }
        val glbPath = file.optString("path", "")
        if (glbPath.isEmpty()) throw IllegalStateException("Нейросеть не вернула модель")
        // ссылка «url» в ответе сервера неверная, рабочая — /file=<путь> (проверено)
        val url = "$BASE/file=$glbPath"

        status("Скачиваю модель…")
        return download(url)
    }

    private const val FLUX = "https://black-forest-labs-flux-1-schnell.hf.space"

    /** Картинка по описанию (бесплатная FLUX.1-schnell). Возвращает байты изображения. Не в UI-потоке. */
    fun textToImage(prompt: String, status: (String) -> Unit): ByteArray {
        status("Рисую картинку по описанию…")
        // 1) Pollinations — бесплатно, без ключей и без лимита видеокарты Hugging Face
        try {
            return pollinations(prompt, (System.currentTimeMillis() % 1000000).toInt())
        } catch (e: Exception) {
            // не вышло — пробуем запасной сервер
        }
        status("Рисую картинку (запасной сервер)…")
        return fluxImage(prompt)
    }

    /** Одна картинка от Pollinations (бесплатно, без ключей); seed задаёт вариант. Не в UI-потоке. */
    fun pollinations(prompt: String, seed: Int, size: Int = 640): ByteArray {
        val q = java.net.URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        val bytes = download("https://image.pollinations.ai/prompt/$q?width=$size&height=$size&nologo=true&model=flux&seed=$seed")
        if (bytes.size < 5000) throw IllegalStateException("пустая картинка")
        return bytes
    }

    /** Запасной рисовальщик: FLUX.1-schnell на Hugging Face (тратит бесплатные минуты видеокарты). */
    private fun fluxImage(prompt: String): ByteArray {
        val data = JSONArray().put(prompt).put(0).put(true).put(768).put(768).put(4)
        val c = URL("$FLUX/gradio_api/call/infer").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("data", data).toString().toByteArray()) }
        if (c.responseCode != 200) throw IllegalStateException(friendly(c.responseCode, err(c)))
        val eventId = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getString("event_id")
        val r = URL("$FLUX/gradio_api/call/infer/$eventId").openConnection() as HttpURLConnection
        r.connectTimeout = 30000
        r.readTimeout = 5 * 60 * 1000
        var event = ""
        var result: String? = null
        r.inputStream.bufferedReader().use { rd ->
            while (true) {
                val line = rd.readLine() ?: break
                if (line.startsWith("event:")) event = line.substring(6).trim()
                else if (line.startsWith("data:")) {
                    val d = line.substring(5).trim()
                    when (event) {
                        "complete" -> { result = d; return@use }
                        "error" -> throw IllegalStateException(friendly(0, d))
                    }
                }
            }
        }
        val img = JSONArray(result ?: throw IllegalStateException("Сервер картинок не ответил, попробуйте ещё раз"))
            .optJSONObject(0) ?: throw IllegalStateException("Не удалось нарисовать картинку")
        var url = img.optString("url", "")
        if (url.isEmpty() || url == "null") url = "$FLUX/gradio_api/file=" + img.getString("path")
        return download(url)
    }

    private fun upload(bytes: ByteArray): String {
        val boundary = "----figurki" + System.nanoTime()
        val c = URL("$BASE/upload").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        c.outputStream.use { o ->
            o.write(("--$boundary\r\nContent-Disposition: form-data; name=\"files\"; filename=\"photo.jpg\"\r\n" +
                "Content-Type: image/jpeg\r\n\r\n").toByteArray())
            o.write(bytes)
            o.write("\r\n--$boundary--\r\n".toByteArray())
        }
        if (c.responseCode != 200) throw IllegalStateException(friendly(c.responseCode, err(c)))
        return JSONArray(c.inputStream.bufferedReader().use { it.readText() }).getString(0)
    }

    private fun download(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 30000
        c.readTimeout = 120000
        if (c.responseCode != 200) throw IllegalStateException("Не удалось скачать модель (ошибка ${c.responseCode})")
        val bos = ByteArrayOutputStream()
        c.inputStream.use { it.copyTo(bos) }
        return bos.toByteArray()
    }

    private fun err(c: HttpURLConnection): String =
        try { c.errorStream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }

    private fun friendly(code: Int, msg: String?): String {
        val m = (msg ?: "").lowercase()
        return when {
            "quota" in m || "zerogpu" in m || code == 429 ->
                "Бесплатный лимит нейросети на сегодня исчерпан — попробуйте через несколько часов"
            code == 503 || code == 502 || "sleep" in m ->
                "Сервер нейросети сейчас занят или спит — попробуйте через пару минут"
            m.isBlank() || m == "null" ->
                "Сервер нейросети отказал без объяснений — чаще всего это дневной бесплатный лимит " +
                    "(около 2 минут работы видеокарты в сутки на один интернет-адрес). " +
                    "Попробуйте позже или через другой интернет: Wi-Fi вместо мобильного или наоборот"
            else -> "Нейросеть не смогла построить модель" + (if (code > 0) " (ошибка $code)" else "")
        }
    }
}
