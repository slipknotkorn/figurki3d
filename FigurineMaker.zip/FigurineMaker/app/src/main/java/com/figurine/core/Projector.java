package com.figurine.core;

import java.util.Arrays;
import java.util.List;

/**
 * Простая программная проекция для предпросмотра: поворот камеры вокруг центра фигурки,
 * лёгкая перспектива, отсечение обратных граней, плоское освещение, сортировка «дальние первыми».
 */
public final class Projector {

    /** Результат одного кадра. Треугольник i: вершины (xy[6i..6i+5]), цвет argb[i], деталь owner[i]. Порядок — от дальних к ближним. */
    public static final class Frame {
        public float[] xy = new float[0];
        public int[] argb = new int[0];
        public int[] owner = new int[0];
        public int count = 0;
        /** Линии сетки стола: x1,y1,x2,y2 подряд. */
        public float[] grid = new float[0];

        /** Номер детали под точкой (px,py) или -1. Ищет от ближнего треугольника к дальнему. */
        public int pick(float px, float py) {
            for (int i = count - 1; i >= 0; i--) {
                int o = i * 6;
                if (inside(px, py, xy[o], xy[o + 1], xy[o + 2], xy[o + 3], xy[o + 4], xy[o + 5])) return owner[i];
            }
            return -1;
        }

        private static boolean inside(float px, float py, float ax, float ay, float bx, float by, float cx, float cy) {
            float d1 = (px - bx) * (ay - by) - (ax - bx) * (py - by);
            float d2 = (px - cx) * (by - cy) - (bx - cx) * (py - cy);
            float d3 = (px - ax) * (cy - ay) - (cx - ax) * (py - ay);
            boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
            return !(neg && pos);
        }
    }

    private Projector() {}

    /**
     * @param yawDeg   поворот вокруг вертикали, градусы
     * @param pitchDeg угол обзора сверху (−89..89)
     * @param zoom     1 — фигурка помещается в окно целиком
     * @param selected индекс подсвечиваемой детали или -1
     */
    public static Frame render(List<Mesh> meshes, int selected, double yawDeg, double pitchDeg, double zoom, float w, float h) {
        Frame fr = new Frame();
        double[] b = Figure.bounds(meshes);
        double cx0 = (b[0] + b[3]) / 2, cy0 = (b[1] + b[4]) / 2, cz0 = (b[2] + b[5]) / 2;
        double dx = b[3] - b[0], dy = b[4] - b[1], dz = b[5] - b[2];
        double radius = Math.max(10.0, 0.5 * Math.sqrt(dx * dx + dy * dy + dz * dz));
        double yaw = Math.toRadians(yawDeg), pit = Math.toRadians(Math.max(-89, Math.min(89, pitchDeg)));
        double cyw = Math.cos(yaw), syw = Math.sin(yaw), ce = Math.cos(pit), se = Math.sin(pit);
        double base = Math.min(w, h) / (2.3 * radius) * zoom;
        double camDist = 4.0 * radius;
        float ox = w / 2f, oy = h / 2f;

        // сетка стола на уровне низа фигурки
        double step = 10;
        double ext = Math.ceil(Math.max(radius, 20) / step) * step;
        int lines = (int) (2 * ext / step) + 1;
        fr.grid = new float[lines * 2 * 4];
        int gi = 0;
        double zf = b[2];
        for (int k = 0; k < lines; k++) {
            double t = -ext + k * step;
            for (int dir = 0; dir < 2; dir++) {
                double x1 = dir == 0 ? -ext : t, y1 = dir == 0 ? t : -ext, x2 = dir == 0 ? ext : t, y2 = dir == 0 ? t : ext;
                double[] p = proj(x1 + cx0, y1 + cy0, zf, cx0, cy0, cz0, cyw, syw, ce, se, base, camDist);
                double[] q = proj(x2 + cx0, y2 + cy0, zf, cx0, cy0, cz0, cyw, syw, ce, se, base, camDist);
                fr.grid[gi++] = (float) (ox + p[0]); fr.grid[gi++] = (float) (oy - p[1]);
                fr.grid[gi++] = (float) (ox + q[0]); fr.grid[gi++] = (float) (oy - q[1]);
            }
        }

        int total = 0;
        for (Mesh m : meshes) total += m.triangleCount();
        float[] xy = new float[total * 6];
        int[] argb = new int[total], owner = new int[total];
        float[] key = new float[total];
        int n = 0;
        for (int mi = 0; mi < meshes.size(); mi++) {
            Mesh m = meshes.get(mi);
            int vc = m.vertexCount();
            double[] vx = new double[vc], vy = new double[vc], vt = new double[vc], sx = new double[vc], sy = new double[vc], dp = new double[vc];
            for (int i = 0; i < vc; i++) {
                double x = m.v[i * 3] - cx0, y = m.v[i * 3 + 1] - cy0, z = m.v[i * 3 + 2] - cz0;
                double x1 = cyw * x - syw * y, y1 = syw * x + cyw * y;
                vx[i] = x1;
                vy[i] = y1 * se + z * ce;          // вверх по экрану
                vt[i] = z * se - y1 * ce;          // к камере
                dp[i] = -vt[i];                    // от камеры
                double k = camDist / (camDist + dp[i]);
                sx[i] = vx[i] * base * k;
                sy[i] = vy[i] * base * k;
            }
            int cr = (m.color >> 16) & 255, cg = (m.color >> 8) & 255, cb = m.color & 255;
            if (mi == selected) { // подсветка выбранной детали
                cr = (int) (cr * 0.65 + 255 * 0.35); cg = (int) (cg * 0.65 + 190 * 0.35); cb = (int) (cb * 0.65 + 0 * 0.35);
            }
            for (int i = 0; i < m.t.length; i += 3) {
                int a = m.t[i], bb = m.t[i + 1], c = m.t[i + 2];
                // отсечение обратных граней по ориентации на экране (y вверх: против часовой = лицевая)
                double area = (sx[bb] - sx[a]) * (sy[c] - sy[a]) - (sx[c] - sx[a]) * (sy[bb] - sy[a]);
                if (area <= 0) continue;
                double ux = vx[bb] - vx[a], uy = vy[bb] - vy[a], ut = vt[bb] - vt[a];
                double wx = vx[c] - vx[a], wy = vy[c] - vy[a], wt = vt[c] - vt[a];
                double nx = uy * wt - ut * wy, ny = ut * wx - ux * wt, nt = ux * wy - uy * wx;
                double len = Math.sqrt(nx * nx + ny * ny + nt * nt);
                double lit = 0.35;
                if (len > 1e-12) lit += 0.65 * Math.max(0, (nx * -0.4 + ny * 0.6 + nt * 0.7) / (len * 1.005));
                lit = Math.min(1.0, lit);
                int o = n * 6;
                xy[o] = (float) (ox + sx[a]);  xy[o + 1] = (float) (oy - sy[a]);
                xy[o + 2] = (float) (ox + sx[bb]); xy[o + 3] = (float) (oy - sy[bb]);
                xy[o + 4] = (float) (ox + sx[c]);  xy[o + 5] = (float) (oy - sy[c]);
                argb[n] = (255 << 24) | ((int) (cr * lit) << 16) | ((int) (cg * lit) << 8) | (int) (cb * lit);
                owner[n] = mi;
                key[n] = (float) ((dp[a] + dp[bb] + dp[c]) / 3.0);
                n++;
            }
        }
        // сортировка: дальние (большой key) первыми
        Integer[] idx = new Integer[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        Arrays.sort(idx, (p, q) -> Float.compare(key[q], key[p]));
        fr.xy = new float[n * 6];
        fr.argb = new int[n];
        fr.owner = new int[n];
        for (int i = 0; i < n; i++) {
            int s = idx[i];
            System.arraycopy(xy, s * 6, fr.xy, i * 6, 6);
            fr.argb[i] = argb[s];
            fr.owner[i] = owner[s];
        }
        fr.count = n;
        return fr;
    }

    private static double[] proj(double x, double y, double z, double cx0, double cy0, double cz0,
                                 double cyw, double syw, double ce, double se, double base, double camDist) {
        x -= cx0; y -= cy0; z -= cz0;
        double x1 = cyw * x - syw * y, y1 = syw * x + cyw * y;
        double up = y1 * se + z * ce, dp = y1 * ce - z * se;
        double k = camDist / (camDist + dp);
        return new double[]{x1 * base * k, up * base * k};
    }
}
