package com.figurine.core;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Фото → рельефная фигурка. Шаги: выделить объект (маска), надуть по расстоянию до края
 * (получается «подушка» точно по силуэту), добавить мелкий рельеф по яркости фото,
 * собрать замкнутую сетку с плоской спинкой.
 *
 * Изображения приходят построчно сверху вниз (как в Android Bitmap): индекс = row * w + col.
 */
public final class Photo3D {
    private Photo3D() {}

    // =====================================================================
    //  Выделение объекта
    // =====================================================================

    /**
     * Выделение по цвету фона: фон оценивается по рамке снимка (до трёх цветов),
     * порог подбирается автоматически (Оцу) и сдвигается ползунком.
     *
     * @param sensitivity 0..1; больше — больше захватывается в объект
     * @param invert      поменять местами объект и фон
     */
    public static boolean[] segment(int[] argb, int w, int h, double sensitivity, boolean invert) {
        int n = w * h;
        double[][] lab = new double[n][];
        for (int i = 0; i < n; i++) lab[i] = lab(argb[i]);

        // пиксели рамки
        int bw = Math.max(1, Math.min(2, Math.min(w, h) / 20));
        ArrayList<double[]> border = new ArrayList<>();
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if (x < bw || y < bw || x >= w - bw || y >= h - bw) border.add(lab[y * w + x]);

        // k-средних по рамке, k = 3, начальные центры — самые далёкие друг от друга
        int k = Math.min(3, border.size());
        double[][] centers = new double[k][];
        centers[0] = border.get(border.size() / 2).clone();
        for (int c = 1; c < k; c++) {
            double best = -1;
            double[] pick = centers[0];
            for (double[] p : border) {
                double dmin = 1e18;
                for (int q = 0; q < c; q++) dmin = Math.min(dmin, dist(p, centers[q]));
                if (dmin > best) { best = dmin; pick = p; }
            }
            centers[c] = pick.clone();
        }
        int[] cnt = new int[k];
        for (int it = 0; it < 10; it++) {
            double[][] sum = new double[k][3];
            Arrays.fill(cnt, 0);
            for (double[] p : border) {
                int bi = 0;
                double bd = 1e18;
                for (int c = 0; c < k; c++) { double d = dist(p, centers[c]); if (d < bd) { bd = d; bi = c; } }
                cnt[bi]++;
                for (int j = 0; j < 3; j++) sum[bi][j] += p[j];
            }
            for (int c = 0; c < k; c++)
                if (cnt[c] > 0) for (int j = 0; j < 3; j++) centers[c][j] = sum[c][j] / cnt[c];
        }
        ArrayList<double[]> bg = new ArrayList<>();
        int top = 0;
        for (int c = 1; c < k; c++) if (cnt[c] > cnt[top]) top = c;
        for (int c = 0; c < k; c++) if (cnt[c] >= 0.08 * border.size() || c == top) bg.add(centers[c]);

        double[] dd = new double[n];
        for (int i = 0; i < n; i++) {
            double m = 1e18;
            for (double[] c : bg) m = Math.min(m, dist(lab[i], c));
            dd[i] = Math.min(m, 100);
        }
        // шум фона: 95-й процентиль расстояний пикселей рамки до цвета фона
        double[] bdist = new double[border.size()];
        for (int i = 0; i < bdist.length; i++) {
            double m = 1e18;
            for (double[] c : bg) m = Math.min(m, dist(border.get(i), c));
            bdist[i] = m;
        }
        Arrays.sort(bdist);
        double d95 = bdist.length == 0 ? 0 : bdist[(int) (0.95 * (bdist.length - 1))];
        double low = Math.max(6.0, 1.8 * d95);          // чуть выше шума фона: берём всё, что заметно отличается
        double high = Math.max(low, otsu(dd));          // граница между «явным объектом» и фоном по Оцу
        double sens = Math.max(0, Math.min(1, sensitivity));
        double thr = high * Math.pow(low / high, sens); // 0 — строго по Оцу, 1 — почти по шуму фона
        boolean[] mask = new boolean[n];
        for (int i = 0; i < n; i++) mask[i] = (dd[i] > thr) != invert;
        return cleanMask(mask, w, h);
    }

    /** Маска из карты уверенности (например, от нейросети): conf > threshold. */
    public static boolean[] fromConfidence(float[] conf, int w, int h, double threshold, boolean invert) {
        boolean[] mask = new boolean[w * h];
        for (int i = 0; i < mask.length; i++) mask[i] = (conf[i] > threshold) != invert;
        return cleanMask(mask, w, h);
    }

    /** Склеить мелкие щели, оставить самую большую связную область, заполнить мелкие дырки. */
    public static boolean[] cleanMask(boolean[] mask, int w, int h) {
        boolean[] m = erode(dilate(mask, w, h), w, h);          // закрытие
        m = significantComponents(m, w, h, 0.15);
        // дырки: фоновые области, не касающиеся края и меньше 3% кадра, закрашиваем
        int n = w * h;
        boolean[] bgSeen = new boolean[n];
        int limit = (int) (0.03 * n);
        for (int s = 0; s < n; s++) {
            if (m[s] || bgSeen[s]) continue;
            ArrayList<Integer> comp = new ArrayList<>();
            boolean touches = false;
            ArrayDeque<Integer> q = new ArrayDeque<>();
            q.add(s);
            bgSeen[s] = true;
            while (!q.isEmpty()) {
                int p = q.poll();
                comp.add(p);
                int x = p % w, y = p / w;
                if (x == 0 || y == 0 || x == w - 1 || y == h - 1) touches = true;
                if (x > 0 && !m[p - 1] && !bgSeen[p - 1]) { bgSeen[p - 1] = true; q.add(p - 1); }
                if (x < w - 1 && !m[p + 1] && !bgSeen[p + 1]) { bgSeen[p + 1] = true; q.add(p + 1); }
                if (y > 0 && !m[p - w] && !bgSeen[p - w]) { bgSeen[p - w] = true; q.add(p - w); }
                if (y < h - 1 && !m[p + w] && !bgSeen[p + w]) { bgSeen[p + w] = true; q.add(p + w); }
            }
            if (!touches && comp.size() <= limit) for (int p : comp) m[p] = true;
        }
        return m;
    }

    private static boolean[] dilate(boolean[] m, int w, int h) {
        boolean[] o = new boolean[m.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                boolean v = m[y * w + x];
                if (!v && x > 0) v = m[y * w + x - 1];
                if (!v && x < w - 1) v = m[y * w + x + 1];
                if (!v && y > 0) v = m[(y - 1) * w + x];
                if (!v && y < h - 1) v = m[(y + 1) * w + x];
                o[y * w + x] = v;
            }
        return o;
    }

    private static boolean[] erode(boolean[] m, int w, int h) {
        boolean[] o = new boolean[m.length];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) {
                boolean v = m[y * w + x];
                // за краем кадра считаем «объект» (иначе закрытие съедает объект, упирающийся в край)
                if (v && x > 0) v = m[y * w + x - 1];
                if (v && x < w - 1) v = m[y * w + x + 1];
                if (v && y > 0) v = m[(y - 1) * w + x];
                if (v && y < h - 1) v = m[(y + 1) * w + x];
                o[y * w + x] = v;
            }
        return o;
    }

    /** Оставляет самую большую связную область и все, что не меньше minFraction от неё (голова за узкой шеей и т.п.). */
    private static boolean[] significantComponents(boolean[] m, int w, int h, double minFraction) {
        int n = w * h;
        int[] label = new int[n];
        ArrayList<Integer> sizes = new ArrayList<>();
        sizes.add(0);
        int cur = 0, bestSize = 0;
        for (int s = 0; s < n; s++) {
            if (!m[s] || label[s] != 0) continue;
            cur++;
            int size = 0;
            ArrayDeque<Integer> q = new ArrayDeque<>();
            q.add(s);
            label[s] = cur;
            while (!q.isEmpty()) {
                int p = q.poll();
                size++;
                int x = p % w, y = p / w;
                if (x > 0 && m[p - 1] && label[p - 1] == 0) { label[p - 1] = cur; q.add(p - 1); }
                if (x < w - 1 && m[p + 1] && label[p + 1] == 0) { label[p + 1] = cur; q.add(p + 1); }
                if (y > 0 && m[p - w] && label[p - w] == 0) { label[p - w] = cur; q.add(p - w); }
                if (y < h - 1 && m[p + w] && label[p + w] == 0) { label[p + w] = cur; q.add(p + w); }
            }
            sizes.add(size);
            bestSize = Math.max(bestSize, size);
        }
        boolean[] o = new boolean[n];
        for (int i = 0; i < n; i++) o[i] = label[i] != 0 && sizes.get(label[i]) >= minFraction * bestSize;
        return o;
    }

    @SuppressWarnings("unused")
    private static boolean[] largestComponent(boolean[] m, int w, int h, boolean value) {
        int n = w * h;
        int[] label = new int[n];
        int best = 0, bestSize = 0, cur = 0;
        for (int s = 0; s < n; s++) {
            if (!m[s] || label[s] != 0) continue;
            cur++;
            int size = 0;
            ArrayDeque<Integer> q = new ArrayDeque<>();
            q.add(s);
            label[s] = cur;
            while (!q.isEmpty()) {
                int p = q.poll();
                size++;
                int x = p % w, y = p / w;
                if (x > 0 && m[p - 1] && label[p - 1] == 0) { label[p - 1] = cur; q.add(p - 1); }
                if (x < w - 1 && m[p + 1] && label[p + 1] == 0) { label[p + 1] = cur; q.add(p + 1); }
                if (y > 0 && m[p - w] && label[p - w] == 0) { label[p - w] = cur; q.add(p - w); }
                if (y < h - 1 && m[p + w] && label[p + w] == 0) { label[p + w] = cur; q.add(p + w); }
            }
            if (size > bestSize) { bestSize = size; best = cur; }
        }
        boolean[] o = new boolean[n];
        if (best == 0) return o;
        for (int i = 0; i < n; i++) o[i] = label[i] == best;
        return o;
    }

    private static double otsu(double[] v) {
        int bins = 100;
        double[] hist = new double[bins];
        for (double x : v) hist[Math.min(bins - 1, (int) x)]++;
        double total = v.length, sumAll = 0;
        for (int i = 0; i < bins; i++) sumAll += i * hist[i];
        double wB = 0, sumB = 0, bestVar = -1, bestT = 10;
        for (int t = 0; t < bins; t++) {
            wB += hist[t];
            if (wB == 0) continue;
            double wF = total - wB;
            if (wF == 0) break;
            sumB += t * hist[t];
            double mB = sumB / wB, mF = (sumAll - sumB) / wF;
            double var = wB * wF * (mB - mF) * (mB - mF);
            if (var > bestVar) { bestVar = var; bestT = t + 1; }
        }
        return bestT;
    }

    private static double dist(double[] a, double[] b) {
        double x = a[0] - b[0], y = a[1] - b[1], z = a[2] - b[2];
        return Math.sqrt(x * x + y * y + z * z);
    }

    private static double[] lab(int argb) {
        double r = lin(((argb >> 16) & 255) / 255.0), g = lin(((argb >> 8) & 255) / 255.0), b = lin((argb & 255) / 255.0);
        double x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047;
        double y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
        double z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883;
        double fx = f(x), fy = f(y), fz = f(z);
        return new double[]{116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)};
    }

    private static double lin(double c) { return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
    private static double f(double t) { return t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16.0 / 116; }
    static double luma(int argb) {
        return (0.299 * ((argb >> 16) & 255) + 0.587 * ((argb >> 8) & 255) + 0.114 * (argb & 255)) / 255.0;
    }

    // =====================================================================
    //  Построение рельефной фигурки
    // =====================================================================

    /**
     * @param mask        маска объекта (w*h, строки сверху вниз)
     * @param argb        исходные пиксели того же размера (для мелкого рельефа по яркости)
     * @param sizeMm      размер фигурки по большей стороне контура, мм
     * @param thicknessMm наибольшая высота «подушки» над плоской спинкой, мм
     * @param detail      0..1 — сколько рельефа добавлять по яркости фото
     * @return замкнутая сетка (плоская спинка на Z=0, выпуклость вверх) или null, если объекта нет
     */
    public static Mesh[] build(boolean[] mask, int[] argb, int w, int h, double sizeMm, double thicknessMm,
                               double detail, double inkLevel, double inkHeightMm, int color, int inkColor, String name) {
        return build(mask, argb, w, h, sizeMm, thicknessMm, detail, inkLevel, inkHeightMm, color, inkColor, name, 0.0);
    }

    /** @param smooth 0..1 — гладкость: сглаживание контура (убирает «лесенку» пикселей) и поверхности */
    public static Mesh[] build(boolean[] mask, int[] argb, int w, int h, double sizeMm, double thicknessMm,
                               double detail, double inkLevel, double inkHeightMm, int color, int inkColor, String name,
                               double smooth) {
        smooth = Math.max(0, Math.min(1, smooth));
        int W = w + 2, H = h + 2;   // рамка из пустых клеток вокруг
        boolean[] m = new boolean[W * H];
        double[] lum = new double[W * H];
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++) {
                int idx = (h - r) * W + (c + 1);       // строка снизу вверх: Y растёт вверх
                m[idx] = mask[r * w + c];
                lum[idx] = luma(argb[r * w + c]);
            }
        removePinches(m, W, H);

        int minX = W, maxX = -1, minY = H, maxY = -1;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                if (m[y * W + x]) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        if (maxX < 0) return null;
        double cell = sizeMm / Math.max(maxX - minX + 1, maxY - minY + 1);
        double xc = (minX + maxX + 1) / 2.0, yc = (minY + maxY + 1) / 2.0;

        // расстояние до края (в клетках)
        double[] d = edt(m, W, H);
        double dmax = 0;
        for (int i = 0; i < d.length; i++) if (m[i]) { d[i] = Math.sqrt(d[i]); dmax = Math.max(dmax, d[i]); }
        double dcap = Math.max(2.0, 0.55 * dmax);
        // расстояние до края у «лесенки» пикселей скачет (1 / 1.4 / 1 …) — это и есть полосы у края.
        // Сглаживаем поле расстояний внутри фигуры, контур при этом остаётся на месте.
        int dpass = (int) Math.round(8 * smooth);
        for (int pass = 0; pass < dpass; pass++) d = smoothInside(d, m, W, H);

        // локальная яркость → мелкий рельеф (лицо, складки, узоры)
        double[] blur = boxBlur(lum, W, H, Math.max(2, (int) (dcap * 0.5)));
        double[] lumS = boxBlur(boxBlur(lum, W, H, 1), W, H, 1);   // убираем шум матрицы
        double[] f = new double[W * H];
        for (int i = 0; i < f.length; i++) {
            if (!m[i]) continue;
            double s = Math.min(1.0, d[i] / dcap);
            double g = Math.sqrt(Math.max(0, 2 * s - s * s));      // четверть окружности: у края круто, в середине плато
            double dl = lumS[i] - blur[i];
            dl = Math.signum(dl) * Math.max(0, Math.abs(dl) - 0.02);   // мёртвая зона: мелкий шум рельефа не даёт
            double det = Math.max(-1, Math.min(1, dl * 4.0));
            f[i] = thicknessMm * g + detail * thicknessMm * 0.3 * det * Math.min(1.0, d[i] / (0.5 * dcap));
            if (f[i] < 0) f[i] = 0;
        }
        int passes = 2 + (int) Math.round(4 * smooth);
        for (int pass = 0; pass < passes; pass++) f = smoothInside(f, m, W, H);

        double t0 = Math.max(1.2, 0.05 * thicknessMm);   // минимальная толщина стенки

        // вершины: верх и низ на каждом углу сетки
        int cw = W + 1, ch = H + 1;
        int[] topId = new int[cw * ch], botId = new int[cw * ch];
        Arrays.fill(topId, -1);
        Arrays.fill(botId, -1);
        int[] nb = new int[cw * ch * 3];   // соседи по контуру: [кол-во, сосед1, сосед2]
        double[] vx = new double[1024];
        int[] tri = new int[4096];
        int nv = 0, nt = 0;
        // локальные ссылки на растущие буферы через массивы-обёртки
        double[][] vbuf = {vx};
        int[][] tbuf = {tri};
        int[] counts = {0, 0};

        for (int cy = 0; cy < H; cy++) {
            for (int cx = 0; cx < W; cx++) {
                if (!m[cy * W + cx]) continue;
                int p00 = cy * cw + cx, p10 = cy * cw + cx + 1, p11 = (cy + 1) * cw + cx + 1, p01 = (cy + 1) * cw + cx;
                int[] corner = {p00, p10, p11, p01};
                int[] cxs = {cx, cx + 1, cx + 1, cx}, cys = {cy, cy, cy + 1, cy + 1};
                int[] tp = new int[4], bt = new int[4];
                for (int k = 0; k < 4; k++) {
                    int pid = corner[k];
                    if (topId[pid] < 0) {
                        double z = t0 + cornerHeight(f, m, W, H, cxs[k], cys[k]);
                        topId[pid] = addVertex(vbuf, counts, (cxs[k] - xc) * cell, (cys[k] - yc) * cell, z);
                        botId[pid] = addVertex(vbuf, counts, (cxs[k] - xc) * cell, (cys[k] - yc) * cell, 0);
                    }
                    tp[k] = topId[pid];
                    bt[k] = botId[pid];
                }
                // верх (нормаль +Z) и спинка (нормаль -Z)
                addTri(tbuf, counts, tp[0], tp[1], tp[2]);
                addTri(tbuf, counts, tp[0], tp[2], tp[3]);
                addTri(tbuf, counts, bt[0], bt[2], bt[1]);
                addTri(tbuf, counts, bt[0], bt[3], bt[2]);
                // стены там, где сосед — пустота
                if (!m[cy * W + cx + 1]) { wall(tbuf, counts, bt[1], bt[2], tp[2], tp[1]); link(nb, p10, p11); }   // +X
                if (!m[cy * W + cx - 1]) { wall(tbuf, counts, bt[3], bt[0], tp[0], tp[3]); link(nb, p01, p00); }   // -X
                if (!m[(cy + 1) * W + cx]) { wall(tbuf, counts, bt[2], bt[3], tp[3], tp[2]); link(nb, p11, p01); } // +Y
                if (!m[(cy - 1) * W + cx]) { wall(tbuf, counts, bt[0], bt[1], tp[1], tp[0]); link(nb, p00, p10); } // -Y
            }
        }
        nv = counts[0];
        nt = counts[1];
        if (smooth > 0) {
            double[] orig = Arrays.copyOf(vbuf[0], nv * 3);
            smoothOutline(vbuf[0], topId, botId, nb, cw, ch, smooth);
            unflip(vbuf[0], orig, tbuf[0], nt);
        }
        Mesh body = new Mesh(Arrays.copyOf(vbuf[0], nv * 3), Arrays.copyOf(tbuf[0], nt * 3), color, name + " (белое)");
        Mesh ink = null;
        if (inkLevel >= 0 && inkHeightMm > 0)
            ink = buildInk(m, f, lum, W, H, t0, cell, xc, yc, inkLevel, inkHeightMm, inkColor, name + " (чёрное)");
        return new Mesh[]{body, ink};
    }

    /**
     * Чёрные детали: тёмные места фото становятся тонким слоем, лежащим на поверхности белого корпуса
     * (низ слоя совпадает с верхом корпуса). Слой — отдельная замкнутая сетка, поэтому в слайсере
     * ему можно назначить второй пластик. Возвращает null, если тёмных мест нет.
     *
     * @param level 0..1: порог яркости между тёмными и светлыми участками объекта (больше — чернее)
     */
    private static Mesh buildInk(boolean[] m, double[] f, double[] lum, int W, int H, double t0, double cell,
                                 double xc, double yc, double level, double inkH, int color, String name) {
        double[] sm = boxBlur(lum, W, H, 1);
        int cnt = 0;
        for (boolean b : m) if (b) cnt++;
        if (cnt == 0) return null;
        double[] arr = new double[cnt];
        int k0 = 0;
        for (int i = 0; i < m.length; i++) if (m[i]) arr[k0++] = sm[i];
        Arrays.sort(arr);
        double lo = arr[(int) (0.05 * (cnt - 1))], hi = arr[(int) (0.95 * (cnt - 1))];
        double thr = lo + (hi - lo) * Math.max(0, Math.min(1, level));
        boolean[] D = new boolean[W * H];
        for (int i = 0; i < D.length; i++) D[i] = m[i] && sm[i] < thr;
        D = dilate(erode(D, W, H), W, H);                       // открытие: убрать одиночные точки
        D = removeSmall(D, W, H, Math.max(4, (int) (0.002 * cnt)));
        for (int i = 0; i < D.length; i++) D[i] = D[i] && m[i];
        removePinchesShrink(D, W, H);

        int cw = W + 1, ch = H + 1;
        int[] topId = new int[cw * ch], botId = new int[cw * ch];
        Arrays.fill(topId, -1);
        Arrays.fill(botId, -1);
        double[][] vbuf = {new double[1024]};
        int[][] tbuf = {new int[4096]};
        int[] counts = {0, 0};
        for (int cy = 0; cy < H; cy++) {
            for (int cx = 0; cx < W; cx++) {
                if (!D[cy * W + cx]) continue;
                int[] cxs = {cx, cx + 1, cx + 1, cx}, cys = {cy, cy, cy + 1, cy + 1};
                int[] tp = new int[4], bt = new int[4];
                for (int k = 0; k < 4; k++) {
                    int pid = cys[k] * cw + cxs[k];
                    if (topId[pid] < 0) {
                        double zb = t0 + cornerHeight(f, m, W, H, cxs[k], cys[k]);
                        topId[pid] = addVertex(vbuf, counts, (cxs[k] - xc) * cell, (cys[k] - yc) * cell, zb + inkH);
                        botId[pid] = addVertex(vbuf, counts, (cxs[k] - xc) * cell, (cys[k] - yc) * cell, zb);
                    }
                    tp[k] = topId[pid];
                    bt[k] = botId[pid];
                }
                addTri(tbuf, counts, tp[0], tp[1], tp[2]);
                addTri(tbuf, counts, tp[0], tp[2], tp[3]);
                addTri(tbuf, counts, bt[0], bt[2], bt[1]);
                addTri(tbuf, counts, bt[0], bt[3], bt[2]);
                if (!D[cy * W + cx + 1]) wall(tbuf, counts, bt[1], bt[2], tp[2], tp[1]);
                if (!D[cy * W + cx - 1]) wall(tbuf, counts, bt[3], bt[0], tp[0], tp[3]);
                if (!D[(cy + 1) * W + cx]) wall(tbuf, counts, bt[2], bt[3], tp[3], tp[2]);
                if (!D[(cy - 1) * W + cx]) wall(tbuf, counts, bt[0], bt[1], tp[1], tp[0]);
            }
        }
        if (counts[1] == 0) return null;
        return new Mesh(Arrays.copyOf(vbuf[0], counts[0] * 3), Arrays.copyOf(tbuf[0], counts[1] * 3), color, name);
    }

    /** Удаляет связные области меньше minArea клеток. */
    static boolean[] removeSmall(boolean[] m, int w, int h, int minArea) {
        int n = w * h;
        boolean[] seen = new boolean[n], out = m.clone();
        for (int s = 0; s < n; s++) {
            if (!m[s] || seen[s]) continue;
            ArrayList<Integer> comp = new ArrayList<>();
            ArrayDeque<Integer> q = new ArrayDeque<>();
            q.add(s);
            seen[s] = true;
            while (!q.isEmpty()) {
                int p = q.poll();
                comp.add(p);
                int x = p % w, y = p / w;
                if (x > 0 && m[p - 1] && !seen[p - 1]) { seen[p - 1] = true; q.add(p - 1); }
                if (x < w - 1 && m[p + 1] && !seen[p + 1]) { seen[p + 1] = true; q.add(p + 1); }
                if (y > 0 && m[p - w] && !seen[p - w]) { seen[p - w] = true; q.add(p - w); }
                if (y < h - 1 && m[p + w] && !seen[p + w]) { seen[p + w] = true; q.add(p + w); }
            }
            if (comp.size() < minArea) for (int p : comp) out[p] = false;
        }
        return out;
    }

    /** Как removePinches, но убирает клетку вместо достройки (маска только уменьшается). */
    static void removePinchesShrink(boolean[] m, int W, int H) {
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int y = 0; y < H - 1; y++)
                for (int x = 0; x < W - 1; x++) {
                    boolean a = m[y * W + x], b = m[y * W + x + 1], c = m[(y + 1) * W + x], d = m[(y + 1) * W + x + 1];
                    if (a && d && !b && !c) { m[y * W + x] = false; changed = true; }
                    else if (b && c && !a && !d) { m[y * W + x + 1] = false; changed = true; }
                }
        }
    }

    /**
     * Где после сглаживания треугольник верха вывернулся (на резких изгибах контура), возвращаем его
     * вершины назад к исходному положению — по половине за проход, в конце полностью.
     * Нижняя вершина угла всегда идёт сразу после верхней (id + 1) и двигается вместе с ней.
     */
    static void unflip(double[] v, double[] orig, int[] t, int nt) {
        unflip(v, orig, t, nt, null);
    }

    /** @param isTop какие вершины — лицевые (null: лицевые все, у кого z ≠ 0) */
    static void unflip(double[] v, double[] orig, int[] t, int nt, boolean[] isTop) {
        for (int round = 0; round < 12; round++) {
            boolean any = false;
            double back = round < 11 ? 0.5 : 1.0;
            boolean[] fix = new boolean[orig.length / 3];
            for (int i = 0; i < nt * 3; i += 3) {
                int a = t[i], b = t[i + 1], c = t[i + 2];
                if (isTop != null) {
                    if (!isTop[a] || !isTop[b] || !isTop[c]) continue;
                } else if (v[a * 3 + 2] == 0 || v[b * 3 + 2] == 0 || v[c * 3 + 2] == 0) continue;   // спинка и стены
                double ux = v[b * 3] - v[a * 3], uy = v[b * 3 + 1] - v[a * 3 + 1];
                double wx = v[c * 3] - v[a * 3], wy = v[c * 3 + 1] - v[a * 3 + 1];
                if (ux * wy - uy * wx <= 1e-9) { fix[a] = fix[b] = fix[c] = true; any = true; }
            }
            if (!any) return;
            for (int p = 0; p < fix.length; p++) {
                if (!fix[p]) continue;
                for (int q = p; q <= p + 1 && q < fix.length; q++) {   // верх и его низ
                    v[q * 3] += back * (orig[q * 3] - v[q * 3]);
                    v[q * 3 + 1] += back * (orig[q * 3 + 1] - v[q * 3 + 1]);
                }
            }
        }
    }

    static void link(int[] nb, int a, int b) {
        add1(nb, a, b);
        add1(nb, b, a);
    }

    private static void add1(int[] nb, int a, int b) {
        int k = nb[a * 3];
        if (k < 2) nb[a * 3 + 1 + k] = b;
        nb[a * 3] = k + 1;   // >2 — особая точка, её не двигаем
    }

    /**
     * Сглаживает контур: «лесенка» из пикселей превращается в плавную линию (сглаживание Таубина —
     * без усадки фигуры). Затем внутренние узлы сетки плавно подтягиваются следом, чтобы треугольники
     * у края не вытягивались. Двигаются только X/Y, верх и низ угла — одинаково, топология не меняется.
     */
    static void smoothOutline(double[] v, int[] topId, int[] botId, int[] nb, int cw, int ch, double smooth) {
        int n = cw * ch;
        double[] x = new double[n], y = new double[n];
        boolean[] has = new boolean[n], edge = new boolean[n];
        for (int p = 0; p < n; p++) {
            if (topId[p] < 0) continue;
            has[p] = true;
            x[p] = v[topId[p] * 3];
            y[p] = v[topId[p] * 3 + 1];
            edge[p] = nb[p * 3] > 0;
        }
        double[] x0 = x.clone(), y0 = y.clone();
        int iters = 3 + (int) Math.round(17 * smooth);
        double[] nx = new double[n], ny = new double[n];
        for (int it = 0; it < iters; it++) {
            for (int step = 0; step < 2; step++) {
                double lam = step == 0 ? 0.5 : -0.53;
                for (int p = 0; p < n; p++) {
                    nx[p] = x[p];
                    ny[p] = y[p];
                    if (!edge[p] || nb[p * 3] != 2) continue;
                    int a = nb[p * 3 + 1], b = nb[p * 3 + 2];
                    nx[p] = x[p] + lam * ((x[a] + x[b]) / 2 - x[p]);
                    ny[p] = y[p] + lam * ((y[a] + y[b]) / 2 - y[p]);
                }
                System.arraycopy(nx, 0, x, 0, n);
                System.arraycopy(ny, 0, y, 0, n);
            }
        }
        // ограничиваем сдвиг контура (не больше 0.75 клетки), чтобы не задеть соседей
        double cell = 0;
        for (int p = 0; p < n && cell == 0; p++)
            if (has[p] && p + 1 < n && has[p + 1] && (p + 1) % cw != 0) cell = Math.abs(x0[p + 1] - x0[p]);
        if (cell == 0) cell = 1;
        double lim = 0.75 * cell;
        for (int p = 0; p < n; p++) {
            if (!edge[p]) continue;
            double dx = x[p] - x0[p], dy = y[p] - y0[p], L = Math.hypot(dx, dy);
            if (L > lim) { x[p] = x0[p] + dx * lim / L; y[p] = y0[p] + dy * lim / L; }
        }
        // внутренние узлы: несколько проходов сглаживания по 4 соседям, контур закреплён
        int inner = 2 + iters / 2;
        for (int it = 0; it < inner; it++) {
            for (int p = 0; p < n; p++) {
                nx[p] = x[p];
                ny[p] = y[p];
                if (!has[p] || edge[p]) continue;
                int[] q = {p - 1, p + 1, p - cw, p + cw};
                double sx = 0, sy = 0;
                int k = 0;
                for (int j : q) if (j >= 0 && j < n && has[j]) { sx += x[j]; sy += y[j]; k++; }
                if (k == 4) {   // только узлы, окружённые со всех сторон
                    // тянем к среднему соседей, но держим исходное положение (иначе сетка «стекает»)
                    nx[p] = 0.5 * x0[p] + 0.5 * (sx / 4);
                    ny[p] = 0.5 * y0[p] + 0.5 * (sy / 4);
                }
            }
            System.arraycopy(nx, 0, x, 0, n);
            System.arraycopy(ny, 0, y, 0, n);
        }
        for (int p = 0; p < n; p++) {
            if (!has[p]) continue;
            v[topId[p] * 3] = x[p];
            v[topId[p] * 3 + 1] = y[p];
            v[botId[p] * 3] = x[p];
            v[botId[p] * 3 + 1] = y[p];
        }
    }

    static void wall(int[][] tbuf, int[] counts, int a, int b, int c, int d) {
        addTri(tbuf, counts, a, b, c);
        addTri(tbuf, counts, a, c, d);
    }

    static int addVertex(double[][] vbuf, int[] counts, double x, double y, double z) {
        int n = counts[0];
        if ((n + 1) * 3 > vbuf[0].length) vbuf[0] = Arrays.copyOf(vbuf[0], vbuf[0].length * 2);
        vbuf[0][n * 3] = x;
        vbuf[0][n * 3 + 1] = y;
        vbuf[0][n * 3 + 2] = z;
        counts[0] = n + 1;
        return n;
    }

    static void addTri(int[][] tbuf, int[] counts, int a, int b, int c) {
        int n = counts[1];
        if ((n + 1) * 3 > tbuf[0].length) tbuf[0] = Arrays.copyOf(tbuf[0], tbuf[0].length * 2);
        tbuf[0][n * 3] = a;
        tbuf[0][n * 3 + 1] = b;
        tbuf[0][n * 3 + 2] = c;
        counts[1] = n + 1;
    }

    /** Высота в углу сетки — среднее по четырём клеткам вокруг (пустые считаются нулём). */
    private static double cornerHeight(double[] f, boolean[] m, int W, int H, int cx, int cy) {
        double s = 0;
        int k = 0;
        for (int dy = -1; dy <= 0; dy++)
            for (int dx = -1; dx <= 0; dx++) {
                int x = cx + dx, y = cy + dy;
                if (x >= 0 && y >= 0 && x < W && y < H && m[y * W + x]) { s += f[y * W + x]; k++; }
            }
        if (k == 0) return 0;
        // на кромке (не все 4 клетки внутри) — одинаковая доля от среднего, без «зубцов» 1/4–2/4–3/4
        return k == 4 ? s / 4.0 : 0.35 * s / k;
    }

    /**
     * Убирает «касание углами» (две клетки по диагонали, две других пустые): такие точки дали бы
     * неманифолдную сетку. Достраиваем клетку — маска только растёт, поэтому цикл заканчивается.
     */
    static void removePinches(boolean[] m, int W, int H) {
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int y = 0; y < H - 1; y++)
                for (int x = 0; x < W - 1; x++) {
                    boolean a = m[y * W + x], b = m[y * W + x + 1], c = m[(y + 1) * W + x], d = m[(y + 1) * W + x + 1];
                    if (a && d && !b && !c) { m[y * W + x + 1] = true; changed = true; }
                    else if (b && c && !a && !d) { m[y * W + x] = true; changed = true; }
                }
        }
    }

    static double[] smoothInside(double[] f, boolean[] m, int W, int H) {
        double[] o = f.clone();
        for (int y = 1; y < H - 1; y++)
            for (int x = 1; x < W - 1; x++) {
                if (!m[y * W + x]) continue;
                double s = 0;
                int n = 0;
                for (int dy = -1; dy <= 1; dy++)
                    for (int dx = -1; dx <= 1; dx++)
                        if (m[(y + dy) * W + x + dx]) { s += f[(y + dy) * W + x + dx]; n++; }
                o[y * W + x] = 0.5 * f[y * W + x] + 0.5 * s / n;
            }
        return o;
    }

    static double[] boxBlur(double[] src, int W, int H, int r) {
        double[] tmp = new double[src.length], out = new double[src.length];
        for (int y = 0; y < H; y++) {
            double sum = 0;
            for (int x = -r; x <= r; x++) sum += src[y * W + Math.max(0, Math.min(W - 1, x))];
            for (int x = 0; x < W; x++) {
                tmp[y * W + x] = sum / (2 * r + 1);
                sum += src[y * W + Math.min(W - 1, x + r + 1)] - src[y * W + Math.max(0, x - r)];
            }
        }
        for (int x = 0; x < W; x++) {
            double sum = 0;
            for (int y = -r; y <= r; y++) sum += tmp[Math.max(0, Math.min(H - 1, y)) * W + x];
            for (int y = 0; y < H; y++) {
                out[y * W + x] = sum / (2 * r + 1);
                sum += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x];
            }
        }
        return out;
    }

    /** Квадрат расстояния от каждой клетки до ближайшей пустой клетки (Фельценшвальб). У пустых — 0. */
    static double[] edt(boolean[] inside, int W, int H) {
        final double INF = 1e12;
        double[] g = new double[W * H];
        for (int i = 0; i < g.length; i++) g[i] = inside[i] ? INF : 0;
        int n = Math.max(W, H);
        double[] col = new double[n], res = new double[n], z = new double[n + 1];
        int[] v = new int[n];
        for (int x = 0; x < W; x++) {
            for (int y = 0; y < H; y++) col[y] = g[y * W + x];
            edt1d(col, H, res, v, z);
            for (int y = 0; y < H; y++) g[y * W + x] = res[y];
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) col[x] = g[y * W + x];
            edt1d(col, W, res, v, z);
            for (int x = 0; x < W; x++) g[y * W + x] = res[x];
        }
        return g;
    }

    private static void edt1d(double[] f, int n, double[] d, int[] v, double[] z) {
        int k = 0;
        v[0] = 0;
        z[0] = -1e30;
        z[1] = 1e30;
        for (int q = 1; q < n; q++) {
            double s;
            while (true) {
                s = ((f[q] + (double) q * q) - (f[v[k]] + (double) v[k] * v[k])) / (2.0 * q - 2.0 * v[k]);
                if (s <= z[k] && k > 0) k--;
                else break;
            }
            if (s <= z[k]) { // k == 0 и новая парабола ниже всюду
                v[0] = q;
                z[0] = -1e30;
                z[1] = 1e30;
                continue;
            }
            k++;
            v[k] = q;
            z[k] = s;
            z[k + 1] = 1e30;
        }
        k = 0;
        for (int q = 0; q < n; q++) {
            while (z[k + 1] < q) k++;
            d[q] = (double) (q - v[k]) * (q - v[k]) + f[v[k]];
        }
    }

    // =====================================================================
    //  Поза «стоя» с подставкой
    // =====================================================================

    /**
     * Ставит рельеф «на ноги»: спинка становится плоскостью Y=0, выпуклость смотрит к зрителю (−Y),
     * снизу добавляется прямоугольная подставка. Возвращает [фигурка, подставка].
     */
    public static List<Mesh> standing(Mesh relief, Mesh ink, int baseColor) {
        double minZ = 1e18;
        for (int i = 1; i < relief.v.length; i += 3) minZ = Math.min(minZ, relief.v[i]);
        Mesh fig = rotateUp(relief, minZ);
        Mesh inkR = ink == null ? null : rotateUp(ink, minZ);
        double[] b = Figure.bounds(java.util.Collections.singletonList(fig));
        double depth = -b[1];                                   // насколько выпуклость выходит вперёд
        double baseH = 3.0, pad = 3.0;
        Figure.Part base = new Figure.Part(Shapes.BOX, "Подставка",
                (b[0] + b[3]) / 2, -depth / 2 + 1.0, 0.6 - baseH / 2,
                (b[3] - b[0]) + 2 * pad, depth + 2 * pad + 2.0, baseH, baseColor);
        ArrayList<Mesh> out = new ArrayList<>();
        out.add(fig);
        if (inkR != null) out.add(inkR);
        out.add(Figure.buildPart(base, 8));
        return out;
    }

    /** Поворот вокруг X на +90°: (x,y,z) → (x,−z,y); затем сдвиг вниз на minY (старый), чтобы низ был на Z=0. */
    private static Mesh rotateUp(Mesh s, double minOldY) {
        double[] v = new double[s.v.length];
        for (int i = 0; i < v.length; i += 3) {
            v[i] = s.v[i];
            v[i + 1] = -s.v[i + 2];
            v[i + 2] = s.v[i + 1] - minOldY;
        }
        return new Mesh(v, s.t, s.color, s.name);
    }
}
