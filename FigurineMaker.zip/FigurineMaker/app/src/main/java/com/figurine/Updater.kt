package com.figurine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Обновления из открытых релизов GitHub — без ключей и регистрации. */
object Updater {
    private const val REPO = "slipknotkorn/figurki3d"

    class Release(val version: Int, val name: String, val url: String)

    @Suppress("DEPRECATION")
    fun currentVersion(ctx: Context): Int = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (e: Exception) {
        0
    }

    private const val RAW = "https://raw.githubusercontent.com/$REPO/apk"

    /** Открывает соединение с долгими таймаутами (у некоторых провайдеров GitHub отвечает медленно). */
    private fun open(url: String, follow: Boolean): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = follow
        c.connectTimeout = 30000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "Figurki3D")
        return c
    }

    /** Повторяет действие до 3 раз; если все попытки не удались — бросает последнюю ошибку. */
    private fun <T> retry(block: () -> T): T {
        var last: Exception? = null
        repeat(3) { n ->
            try { return block() } catch (e: Exception) { last = e; Thread.sleep(1500L * (n + 1)) }
        }
        throw last ?: IllegalStateException("ошибка сети")
    }

    /**
     * Номер последней версии. Источники по очереди:
     * 1) github.com/…/releases/latest (переадресует на …/releases/tag/v1.N);
     * 2) version.txt в ветке apk на raw.githubusercontent.com.
     * Служебный API GitHub не используем: у него лимит 60 запросов в час на адрес.
     * Вызывать не в UI-потоке.
     */
    fun latest(): Release {
        val errors = ArrayList<String>()
        try {
            return retry {
                val c = open("https://github.com/$REPO/releases/latest", follow = false)
                val loc = c.getHeaderField("Location") ?: ""
                if (c.responseCode !in 300..399 || !loc.contains("/releases/tag/")) throw IllegalStateException("нет релизов")
                val tag = loc.substringAfterLast("/releases/tag/").substringBefore('?')
                val ver = tag.substringAfterLast('.').filter { it.isDigit() }.toInt()
                Release(ver, "Фигурки 3D $tag", "https://github.com/$REPO/releases/download/$tag/Figurki3D-$tag.apk")
            }
        } catch (e: Exception) { errors.add("github: ${e.message}") }
        try {
            return retry {
                val c = open("$RAW/version.txt", follow = true)
                if (c.responseCode != 200) throw IllegalStateException("ошибка ${c.responseCode}")
                val ver = c.inputStream.bufferedReader().use { it.readText() }.trim().toInt()
                Release(ver, "Фигурки 3D v1.$ver", "$RAW/Figurki3D-v1.$ver.apk")
            }
        } catch (e: Exception) { errors.add("raw: ${e.message}") }
        throw IllegalStateException("Не удалось проверить обновления — GitHub не отвечает. Попробуйте позже или через другой интернет")
    }

    /** Скачивает APK в кэш приложения: сначала из релиза, при неудаче — копию из ветки apk. Не в UI-потоке. */
    fun download(ctx: Context, r: Release, progress: (Int) -> Unit): File {
        val tag = "v1.${r.version}"
        val sources = listOf(r.url, "$RAW/Figurki3D-$tag.apk").distinct()
        var last: Exception? = null
        for (src in sources) {
            try {
                return retry { fetch(ctx, src, progress) }
            } catch (e: Exception) { last = e }
        }
        throw IllegalStateException("Не удалось скачать обновление — GitHub не отвечает. Попробуйте позже или через другой интернет")
    }

    private fun fetch(ctx: Context, start: String, progress: (Int) -> Unit): File {
        var url = start
        var conn: HttpURLConnection
        var hops = 0
        while (true) {   // GitHub отдаёт файл через переадресацию на своё хранилище
            conn = open(url, follow = false)
            val code = conn.responseCode
            if (code in 300..399 && hops < 5) {
                url = conn.getHeaderField("Location") ?: throw IllegalStateException("нет ссылки на файл")
                hops++
                continue
            }
            if (code != 200) throw IllegalStateException("ошибка $code")
            break
        }
        val total = conn.contentLength
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val f = File(dir, "update.apk")
        conn.inputStream.use { input ->
            f.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) progress((done * 100 / total).toInt())
                }
            }
        }
        if (total > 0 && f.length() != total.toLong()) throw IllegalStateException("файл скачался не полностью")
        return f
    }

    /** Можно ли ставить APK; если нет — открывает системную настройку «Установка неизвестных приложений». */
    fun ensureInstallAllowed(ctx: Context): Boolean {
        if (ctx.packageManager.canRequestPackageInstalls()) return true
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return false
    }

    /** Открывает системное окно установки (обновление встанет поверх, данные сохранятся). */
    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}
