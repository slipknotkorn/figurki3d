package com.figurine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Обновления из открытых релизов GitHub — без ключей и регистрации. */
object Updater {
    private const val REPO = "slipknotkorn/figurki3d"

    class Release(val version: Int, val name: String, val url: String)

    @Suppress("DEPRECATION")
    fun currentVersion(ctx: Context): Int = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (e: Exception) {
        0
    }

    /** Последний релиз. Вызывать не в UI-потоке. */
    fun latest(): Release {
        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.connectTimeout = 15000
        c.readTimeout = 15000
        val code = c.responseCode
        if (code == 404) throw IllegalStateException("Новых версий пока нет")
        if (code == 403) throw IllegalStateException("GitHub временно ограничил проверки, попробуйте позже")
        if (code != 200) throw IllegalStateException("Не удалось проверить (ошибка $code)")
        val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val tag = json.getString("tag_name")                       // v1.13
        val ver = tag.substringAfterLast('.').filter { it.isDigit() }.toIntOrNull() ?: 0
        val assets = json.getJSONArray("assets")
        var url = ""
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.getString("name").endsWith(".apk")) { url = a.getString("browser_download_url"); break }
        }
        if (url.isEmpty()) throw IllegalStateException("В версии $tag нет файла для установки")
        return Release(ver, json.optString("name", tag), url)
    }

    /** Скачивает APK в кэш приложения. Вызывать не в UI-потоке. */
    fun download(ctx: Context, r: Release, progress: (Int) -> Unit): File {
        var url = r.url
        var conn: HttpURLConnection
        var hops = 0
        while (true) {   // GitHub отдаёт файл через переадресацию на своё хранилище
            conn = URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            val code = conn.responseCode
            if (code in 300..399 && hops < 5) {
                url = conn.getHeaderField("Location") ?: throw IllegalStateException("Нет ссылки на файл")
                hops++
                continue
            }
            if (code != 200) throw IllegalStateException("Не удалось скачать (ошибка $code)")
            break
        }
        val total = conn.contentLength
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val f = File(dir, "update.apk")
        conn.inputStream.use { input ->
            f.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) progress((done * 100 / total).toInt())
                }
            }
        }
        return f
    }

    /** Можно ли ставить APK; если нет — открывает системную настройку «Установка неизвестных приложений». */
    fun ensureInstallAllowed(ctx: Context): Boolean {
        if (ctx.packageManager.canRequestPackageInstalls()) return true
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return false
    }

    /** Открывает системное окно установки (обновление встанет поверх, данные сохранятся). */
    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}
