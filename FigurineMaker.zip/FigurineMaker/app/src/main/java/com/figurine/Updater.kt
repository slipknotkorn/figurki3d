package com.figurine

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Обновления из открытых релизов GitHub — без ключей и регистрации. */
object Updater {
    private const val REPO = "slipknotkorn/figurki3d"

    class Release(val version: Int, val name: String, val url: String)

    @Suppress("DEPRECATION")
    fun currentVersion(ctx: Context): Int = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    } catch (e: Exception) {
        0
    }

    /**
     * Последний релиз — через обычную страницу github.com/…/releases/latest: она переадресует на
     * …/releases/tag/v1.N. У служебного API GitHub лимит 60 запросов в час на интернет-адрес,
     * а мобильные операторы делят один адрес на тысячи абонентов, поэтому API не используем.
     * Вызывать не в UI-потоке.
     */
    fun latest(): Release {
        val c = URL("https://github.com/$REPO/releases/latest").openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 15000
        c.readTimeout = 15000
        val code = c.responseCode
        val loc = c.getHeaderField("Location") ?: ""
        if (code !in 300..399 || !loc.contains("/releases/tag/")) {
            if (code == 404 || loc.isEmpty()) throw IllegalStateException("Новых версий пока нет")
            throw IllegalStateException("Не удалось проверить обновления (ошибка $code)")
        }
        val tag = loc.substringAfterLast("/releases/tag/").substringBefore('?')     // v1.18
        val ver = tag.substringAfterLast('.').filter { it.isDigit() }.toIntOrNull()
            ?: throw IllegalStateException("Не удалось понять номер версии")
        val url = "https://github.com/$REPO/releases/download/$tag/Figurki3D-$tag.apk"
        return Release(ver, "Фигурки 3D $tag", url)
    }

    /** Скачивает APK в кэш приложения. Вызывать не в UI-потоке. */
    fun download(ctx: Context, r: Release, progress: (Int) -> Unit): File {
        var url = r.url
        var conn: HttpURLConnection
        var hops = 0
        while (true) {   // GitHub отдаёт файл через переадресацию на своё хранилище
            conn = URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            val code = conn.responseCode
            if (code in 300..399 && hops < 5) {
                url = conn.getHeaderField("Location") ?: throw IllegalStateException("Нет ссылки на файл")
                hops++
                continue
            }
            if (code != 200) throw IllegalStateException("Не удалось скачать (ошибка $code)")
            break
        }
        val total = conn.contentLength
        val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
        val f = File(dir, "update.apk")
        conn.inputStream.use { input ->
            f.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) progress((done * 100 / total).toInt())
                }
            }
        }
        return f
    }

    /** Можно ли ставить APK; если нет — открывает системную настройку «Установка неизвестных приложений». */
    fun ensureInstallAllowed(ctx: Context): Boolean {
        if (ctx.packageManager.canRequestPackageInstalls()) return true
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return false
    }

    /** Открывает системное окно установки (обновление встанет поверх, данные сохранятся). */
    fun install(ctx: Context, apk: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}
