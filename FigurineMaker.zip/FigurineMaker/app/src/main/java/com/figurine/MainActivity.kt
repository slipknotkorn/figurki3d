package com.figurine

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import com.figurine.core.Mesh
import com.figurine.core.Projector

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                    UpdateBar(Modifier.fillMaxWidth().padding(horizontal = 12.dp))
                    VoiceScreen(Modifier.weight(1f))
                }
            }
        }
    }
}

// ---------- 3D-превью ----------

@Composable
internal fun Preview(
    meshes: List<Mesh>,
    selected: Int,
    onPick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var yaw by remember { mutableFloatStateOf(35f) }
    var pitch by remember { mutableFloatStateOf(25f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    val pick by rememberUpdatedState(onPick)
    val lastFrame = remember { arrayOfNulls<Projector.Frame>(1) }

    Canvas(
        modifier
            .background(Color(0xFFEDEFF3))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, z, _ ->
                    yaw += pan.x * 0.5f
                    pitch = (pitch + pan.y * 0.4f).coerceIn(-85f, 85f)
                    zoom = (zoom * z).coerceIn(0.3f, 6f)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    val i = lastFrame[0]?.pick(pos.x, pos.y) ?: -1
                    if (i >= 0) pick(i)
                }
            }
    ) {
        val fr = Projector.render(
            meshes, selected, yaw.toDouble(), pitch.toDouble(), zoom.toDouble(), size.width, size.height
        )
        lastFrame[0] = fr

        val g = fr.grid
        var k = 0
        while (k + 3 < g.size) {
            drawLine(Color(0x22000000), Offset(g[k], g[k + 1]), Offset(g[k + 2], g[k + 3]), strokeWidth = 1f)
            k += 4
        }

        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            val paint = android.graphics.Paint().apply {
                style = android.graphics.Paint.Style.FILL_AND_STROKE
                strokeWidth = 1f
                isAntiAlias = false
            }
            val path = android.graphics.Path()
            val xy = fr.xy
            for (i in 0 until fr.count) {
                val o = i * 6
                path.rewind()
                path.moveTo(xy[o], xy[o + 1])
                path.lineTo(xy[o + 2], xy[o + 3])
                path.lineTo(xy[o + 4], xy[o + 5])
                path.close()
                paint.color = fr.argb[i]
                nc.drawPath(path, paint)
            }
        }
    }
}
