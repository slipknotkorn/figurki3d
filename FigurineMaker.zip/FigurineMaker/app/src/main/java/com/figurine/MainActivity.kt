package com.figurine

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.figurine.core.Exporters
import com.figurine.core.Figure
import com.figurine.core.Mesh
import com.figurine.core.Projector
import com.figurine.core.Shapes as ShapeKit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                App()
            }
        }
    }
}

// ---------- Параметры детали, которые можно менять ползунками ----------

private class Param(
    val label: String,
    val min: Float,
    val max: Float,
    val get: (Figure.Part) -> Double,
    val set: (Figure.Part, Double) -> Unit,
)

private val PARAMS = listOf(
    Param("Позиция X, мм", -60f, 60f, { it.px }, { p, v -> p.px = v }),
    Param("Позиция Y, мм", -60f, 60f, { it.py }, { p, v -> p.py = v }),
    Param("Позиция Z, мм", -20f, 110f, { it.pz }, { p, v -> p.pz = v }),
    Param("Размер X, мм", 1f, 100f, { it.sx }, { p, v -> p.sx = v }),
    Param("Размер Y, мм", 1f, 100f, { it.sy }, { p, v -> p.sy = v }),
    Param("Размер Z, мм", 1f, 100f, { it.sz }, { p, v -> p.sz = v }),
    Param("Поворот X, °", -180f, 180f, { it.rx }, { p, v -> p.rx = v }),
    Param("Поворот Y, °", -180f, 180f, { it.ry }, { p, v -> p.ry = v }),
    Param("Поворот Z, °", -180f, 180f, { it.rz }, { p, v -> p.rz = v }),
)

private val PALETTE = listOf(
    0xF2F2F2, 0x222222, 0x777777, 0xD93A3A, 0xF28C28, 0xF2C230,
    0x3FA34D, 0x3A6FD9, 0x8E5BD9, 0xE96FA6, 0x8B5A2B, 0xD2A679, 0xF0C8A0,
)

private fun colorOf(rgb: Int) = Color((rgb shr 16) and 255, (rgb shr 8) and 255, rgb and 255)

private fun figureOf(parts: List<Figure.Part>): Figure {
    val f = Figure()
    f.parts.addAll(parts)
    return f
}

private fun loadParts(prefs: SharedPreferences): List<Figure.Part> {
    val saved = Figure.fromText(prefs.getString("figure", null))
    return (saved ?: Figure.preset(0)).parts.toList()
}

// ---------- Главный экран ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("figurine", Context.MODE_PRIVATE) }
    var parts by remember { mutableStateOf(loadParts(prefs)) }
    var selected by remember { mutableIntStateOf(if (parts.isEmpty()) -1 else 0) }
    var showExport by remember { mutableStateOf(false) }
    var heightText by remember { mutableStateOf(prefs.getString("height", "60") ?: "60") }
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    var presetMenu by remember { mutableStateOf(false) }
    var addMenu by remember { mutableStateOf(false) }

    LaunchedEffect(parts) { prefs.edit().putString("figure", figureOf(parts).toText()).apply() }
    LaunchedEffect(heightText) { prefs.edit().putString("height", heightText).apply() }

    val meshes: List<Mesh> = remember(parts) { parts.map { Figure.buildPart(it, 16) } }
    val sel = if (selected in parts.indices) selected else -1

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val data = pending
        if (uri != null && data != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                Toast.makeText(ctx, "Файл сохранён", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Не удалось сохранить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        pending = null
    }

    fun update(i: Int, change: (Figure.Part) -> Unit) {
        parts = parts.mapIndexed { k, p -> if (k == i) p.copy().also(change) else p }
    }

    fun addPart(p: Figure.Part) {
        parts = parts + p
        selected = parts.size - 1
    }

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
    ) {
        // Верхняя панель
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Фигурки 3D", fontSize = 20.sp, modifier = Modifier.weight(1f))
            Box {
                TextButton(onClick = { presetMenu = true }) { Text("Шаблоны") }
                DropdownMenu(expanded = presetMenu, onDismissRequest = { presetMenu = false }) {
                    Figure.PRESET_NAMES.forEachIndexed { i, name ->
                        DropdownMenuItem(
                            text = { Text(name) },
                            onClick = {
                                presetMenu = false
                                parts = Figure.preset(i).parts.toList()
                                selected = 0
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Пустой лист") },
                        onClick = {
                            presetMenu = false
                            parts = emptyList()
                            selected = -1
                        },
                    )
                }
            }
            Button(onClick = { showExport = true }) { Text("Экспорт") }
        }

        // 3D-превью
        Preview(
            meshes = meshes,
            selected = sel,
            onPick = { selected = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.45f),
        )

        // Панель редактирования
        Column(
            Modifier
                .fillMaxWidth()
                .weight(0.55f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (parts.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    itemsIndexed(parts) { i, p ->
                        FilterChip(
                            selected = i == sel,
                            onClick = { selected = i },
                            label = { Text(p.name) },
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                Box {
                    OutlinedButton(onClick = { addMenu = true }) { Text("+ Деталь") }
                    DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                        ShapeKit.NAMES.forEachIndexed { i, name ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    addMenu = false
                                    addPart(Figure.Part(i, name, 0.0, 0.0, 10.0, 20.0, 20.0, 20.0, 0xBDBDBD))
                                },
                            )
                        }
                    }
                }
                if (sel >= 0) {
                    OutlinedButton(onClick = { addPart(parts[sel].copy()) }) { Text("Копия") }
                    OutlinedButton(onClick = { addPart(parts[sel].mirrored()) }) { Text("Зеркало") }
                    OutlinedButton(onClick = {
                        parts = parts.filterIndexed { k, _ -> k != sel }
                        selected = minOf(sel, parts.size - 1)
                    }) { Text("Удалить") }
                }
            }

            if (sel >= 0) {
                val p = parts[sel]
                Text(
                    "${p.name} · ${ShapeKit.NAMES[p.shape]}",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary,
                )
                for (param in PARAMS) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(param.label, fontSize = 13.sp, modifier = Modifier.width(138.dp))
                        Slider(
                            value = param.get(p).toFloat().coerceIn(param.min, param.max),
                            onValueChange = { v -> update(sel) { q -> param.set(q, v.toDouble()) } },
                            valueRange = param.min..param.max,
                            modifier = Modifier.weight(1f),
                        )
                        Text("%.1f".format(param.get(p)), fontSize = 13.sp, modifier = Modifier.width(44.dp))
                    }
                }
                Text("Цвет", fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(PALETTE) { _, c ->
                        Box(
                            Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(colorOf(c))
                                .border(
                                    if (p.color == c) 3.dp else 1.dp,
                                    if (p.color == c) MaterialTheme.colorScheme.primary else Color.Gray,
                                    CircleShape,
                                )
                                .clickable { update(sel) { q -> q.color = c } }
                        )
                    }
                }
            } else {
                Text(
                    "Выберите шаблон или добавьте деталь: шар, цилиндр, конус, куб, купол, кольцо. " +
                        "Из них собирается фигурка. Крутите превью пальцем, масштабируйте щипком, " +
                        "касание выбирает деталь.",
                    fontSize = 14.sp,
                )
            }
        }
    }

    if (showExport) {
        val target = (heightText.replace(',', '.').toDoubleOrNull() ?: 60.0).coerceIn(5.0, 250.0)
        val exportMeshes = remember(parts) { parts.map { Figure.buildPart(it, 40) } }
        val b = Figure.bounds(exportMeshes)
        val h = b[5] - b[2]
        val s = if (h > 1e-9) target / h else 1.0
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Экспорт для Bambu Studio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = heightText,
                        onValueChange = { heightText = it },
                        label = { Text("Высота фигурки при печати, мм") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                    if (parts.isNotEmpty()) {
                        Text(
                            "Размер: %.1f × %.1f × %.1f мм".format((b[3] - b[0]) * s, (b[4] - b[1]) * s, h * s),
                            fontSize = 14.sp,
                        )
                    }
                    Text(
                        "Фигурка ставится низом на стол и центрируется. Перекрывающиеся детали " +
                            "слайсер склеит в одно тело. STL — одним цветом, 3MF — с цветами деталей.",
                        fontSize = 12.sp,
                    )
                    Button(
                        onClick = {
                            if (parts.isEmpty()) {
                                Toast.makeText(ctx, "Добавьте хотя бы одну деталь", Toast.LENGTH_SHORT).show()
                            } else {
                                pending = Exporters.threeMf(exportMeshes, target, "Figurine")
                                showExport = false
                                saver.launch("figurka.3mf")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить 3MF (с цветами)") }
                    OutlinedButton(
                        onClick = {
                            if (parts.isEmpty()) {
                                Toast.makeText(ctx, "Добавьте хотя бы одну деталь", Toast.LENGTH_SHORT).show()
                            } else {
                                pending = Exporters.stl(exportMeshes, target)
                                showExport = false
                                saver.launch("figurka.stl")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить STL") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("Отмена") } },
        )
    }
}

// ---------- 3D-превью ----------

@Composable
private fun Preview(
    meshes: List<Mesh>,
    selected: Int,
    onPick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var yaw by remember { mutableFloatStateOf(35f) }
    var pitch by remember { mutableFloatStateOf(25f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    val pick by rememberUpdatedState(onPick)
    val lastFrame = remember { arrayOfNulls<Projector.Frame>(1) } // последний кадр для выбора касанием

    Canvas(
        modifier
            .background(Color(0xFFEDEFF3))
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, z, _ ->
                    yaw += pan.x * 0.5f
                    pitch = (pitch + pan.y * 0.4f).coerceIn(-85f, 85f)
                    zoom = (zoom * z).coerceIn(0.3f, 6f)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { pos ->
                    val i = lastFrame[0]?.pick(pos.x, pos.y) ?: -1
                    if (i >= 0) pick(i)
                }
            }
    ) {
        val fr = Projector.render(
            meshes, selected, yaw.toDouble(), pitch.toDouble(), zoom.toDouble(), size.width, size.height
        )
        lastFrame[0] = fr

        // сетка стола
        val g = fr.grid
        var k = 0
        while (k + 3 < g.size) {
            drawLine(Color(0x22000000), Offset(g[k], g[k + 1]), Offset(g[k + 2], g[k + 3]), strokeWidth = 1f)
            k += 4
        }

        // треугольники фигурки (уже отсортированы от дальних к ближним)
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            val paint = android.graphics.Paint().apply {
                style = android.graphics.Paint.Style.FILL_AND_STROKE
                strokeWidth = 1f
                isAntiAlias = false
            }
            val path = android.graphics.Path()
            val xy = fr.xy
            for (i in 0 until fr.count) {
                val o = i * 6
                path.rewind()
                path.moveTo(xy[o], xy[o + 1])
                path.lineTo(xy[o + 2], xy[o + 3])
                path.lineTo(xy[o + 4], xy[o + 5])
                path.close()
                paint.color = fr.argb[i]
                nc.drawPath(path, paint)
            }
        }
    }
}
