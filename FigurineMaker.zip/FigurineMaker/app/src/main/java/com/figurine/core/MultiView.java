package com.figurine.core;

import java.util.Arrays;
import java.util.List;

/**
 * Фигурка по нескольким фото: спереди (обязательно), сбоку и сверху (по желанию).
 * Объём — пересечение силуэтов («визуальная оболочка»): глубину в каждой точке ограничивают
 * силуэт сбоку (по высоте) и силуэт сверху (по ширине); края скругляются, чтобы фигурка
 * была не «кубической», а объёмной и гладкой.
 *
 * Договорённость о съёмке: сбоку — предмет передом вправо,
 * сверху — предмет передней стороной к низу кадра.
 */
public final class MultiView {
    private MultiView() {}

    /** Интервал глубины по одной оси силуэта: для каждой строки/столбца [lo, hi] в долях, NaN — пусто. */
    private static final class Profile {
        double[] lo, hi;   // по нормированной координате 0..1 (n отсчётов)
        int n;
        double aspect;     // ширина силуэта (по глубине) / его длина по общей оси
    }

    /**
     * Профиль силуэта: по строкам (rows=true) — для каждой строки снизу вверх интервал столбцов;
     * по столбцам — для каждого столбца слева направо интервал строк (сверху вниз = вперёд).
     */
    private static Profile profile(boolean[] m, int w, int h, boolean rows, boolean flipDepth) {
        int x0 = w, x1 = -1, y0 = h, y1 = -1;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if (m[y * w + x]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
        if (x1 < 0) return null;
        Profile p = new Profile();
        int len = rows ? (y1 - y0 + 1) : (x1 - x0 + 1);      // общая ось (высота или ширина)
        int dep = rows ? (x1 - x0 + 1) : (y1 - y0 + 1);      // глубина
        p.n = len;
        p.lo = new double[len];
        p.hi = new double[len];
        p.aspect = dep / (double) len;
        double c = (dep - 1) / 2.0;
        for (int i = 0; i < len; i++) {
            int lo = Integer.MAX_VALUE, hi = Integer.MIN_VALUE;
            for (int j = 0; j < dep; j++) {
                int x = rows ? x0 + j : x0 + i;
                int y = rows ? (y1 - i) : y0 + j;          // строки снизу вверх
                if (m[y * w + x]) { lo = Math.min(lo, j); hi = Math.max(hi, j); }
            }
            if (hi < lo) { p.lo[i] = Double.NaN; p.hi[i] = Double.NaN; continue; }
            // в долях длины, центр силуэта = 0; «вперёд» = положительно
            double a = (lo - 0.5 - c) / len, b = (hi + 0.5 - c) / len;
            if (flipDepth) { double t = -b; b = -a; a = t; }
            p.lo[i] = a;
            p.hi[i] = b;
        }
        return p;
    }

    private static double at(double[] arr, int n, double u) {
        int i = (int) Math.round(u * (n - 1));
        i = Math.max(0, Math.min(n - 1, i));
        return arr[i];
    }

    /**
     * @param front маска «спереди» (w*h, строки сверху вниз) — обязательна
     * @param side  маска «сбоку» или null
     * @param top   маска «сверху» или null
     * @return фигурка стоя (низ на Z=0, лицом к −Y) + подставка; null, если объекта нет
     */
    public static List<Mesh> build(boolean[] front, int[] argb, int w, int h,
                                   boolean[] side, int sw, int sh,
                                   boolean[] top, int tw, int th,
                                   double sizeMm, double detail, double smooth, int color) {
        int W = w + 2, H = h + 2;
        boolean[] m = new boolean[W * H];
        double[] lum = new double[W * H];
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++) {
                int idx = (h - r) * W + (c + 1);
                m[idx] = front[r * w + c];
                lum[idx] = Photo3D.luma(argb[r * w + c]);
            }
        Photo3D.removePinches(m, W, H);
        int minX = W, maxX = -1, minY = H, maxY = -1;
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                if (m[y * W + x]) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        if (maxX < 0) return null;
        int fw = maxX - minX + 1, fh = maxY - minY + 1;
        double cell = sizeMm / Math.max(fw, fh);
        double xc = (minX + maxX + 1) / 2.0, yc = (minY + maxY + 1) / 2.0;

        Profile ps = side == null ? null : profile(side, sw, sh, true, false);    // сбоку: перёд смотрит вправо
        Profile pt = top == null ? null : profile(top, tw, th, false, false);     // сверху: перёд внизу

        // расстояние до края силуэта спереди — для скругления
        double[] d = Photo3D.edt(m, W, H);
        for (int i = 0; i < d.length; i++) if (m[i]) d[i] = Math.sqrt(d[i]);
        int dpass = (int) Math.round(8 * smooth);
        for (int pass = 0; pass < dpass; pass++) d = Photo3D.smoothInside(d, m, W, H);

        double[] blur = Photo3D.boxBlur(lum, W, H, 4);
        double[] lumS = Photo3D.boxBlur(Photo3D.boxBlur(lum, W, H, 1), W, H, 1);

        double defHalf = 0.18 * Math.max(fw, fh);   // если нет ни бока, ни верха — как одиночное фото
        double[] zf = new double[W * H], zb = new double[W * H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++) {
                int i = y * W + x;
                if (!m[i]) continue;
                double lo = -defHalf, hi = defHalf;
                boolean have = false;
                if (ps != null) {
                    double u = (y - minY + 0.5) / fh;                 // высота 0..1 снизу
                    double a = at(ps.lo, ps.n, u), b = at(ps.hi, ps.n, u);
                    if (!Double.isNaN(a)) { lo = a * fh; hi = b * fh; have = true; }
                }
                if (pt != null) {
                    double u = (x - minX + 0.5) / fw;                 // ширина 0..1 слева
                    double a = at(pt.lo, pt.n, u), b = at(pt.hi, pt.n, u);
                    if (!Double.isNaN(a)) {
                        double a2 = a * fw, b2 = b * fw;
                        if (have) { lo = Math.max(lo, a2); hi = Math.min(hi, b2); } else { lo = a2; hi = b2; have = true; }
                    }
                }
                if (hi - lo < 1.0) { double mid = (lo + hi) / 2; lo = mid - 0.5; hi = mid + 0.5; }
                double half = (hi - lo) / 2, mid = (lo + hi) / 2;
                // скругление: у края силуэта толщина плавно сходит (радиус ~ половина толщины)
                double s = Math.min(1.0, d[i] / Math.max(1.5, half));
                double g = Math.sqrt(Math.max(0, 2 * s - s * s));
                double dl = lumS[i] - blur[i];
                dl = Math.signum(dl) * Math.max(0, Math.abs(dl) - 0.02);
                double det = Math.max(-1, Math.min(1, dl * 4.0)) * detail * 0.12 * half * Math.min(1, s * 2);
                zf[i] = mid + half * g + det;
                zb[i] = mid - half * g;
            }
        int passes = 2 + (int) Math.round(4 * smooth);
        for (int pass = 0; pass < passes; pass++) {
            zf = Photo3D.smoothInside(zf, m, W, H);
            zb = Photo3D.smoothInside(zb, m, W, H);
        }

        // --- сетка: лицевая (к зрителю) и обратная поверхности, стенки по контуру ---
        double t0 = Math.max(0.8, 1.2 / cell);   // минимальная толщина ≈ 1.2 мм (в клетках)
        int cw = W + 1, ch = H + 1;
        int[] topId = new int[cw * ch], botId = new int[cw * ch];
        Arrays.fill(topId, -1);
        Arrays.fill(botId, -1);
        int[] nb = new int[cw * ch * 3];
        double[][] vbuf = {new double[1024]};
        int[][] tbuf = {new int[4096]};
        int[] counts = {0, 0};
        for (int cy = 0; cy < H; cy++)
            for (int cx = 0; cx < W; cx++) {
                if (!m[cy * W + cx]) continue;
                int p00 = cy * cw + cx, p10 = cy * cw + cx + 1, p11 = (cy + 1) * cw + cx + 1, p01 = (cy + 1) * cw + cx;
                int[] corner = {p00, p10, p11, p01};
                int[] cxs = {cx, cx + 1, cx + 1, cx}, cys = {cy, cy, cy + 1, cy + 1};
                int[] tp = new int[4], bt = new int[4];
                for (int k = 0; k < 4; k++) {
                    int pid = corner[k];
                    if (topId[pid] < 0) {
                        double[] fb = corner(zf, zb, m, W, H, cxs[k], cys[k], t0);
                        double X = (cxs[k] - xc), Y = (cys[k] - yc);
                        topId[pid] = Photo3D.addVertex(vbuf, counts, X, Y, fb[0]);
                        botId[pid] = Photo3D.addVertex(vbuf, counts, X, Y, fb[1]);
                    }
                    tp[k] = topId[pid];
                    bt[k] = botId[pid];
                }
                Photo3D.addTri(tbuf, counts, tp[0], tp[1], tp[2]);
                Photo3D.addTri(tbuf, counts, tp[0], tp[2], tp[3]);
                Photo3D.addTri(tbuf, counts, bt[0], bt[2], bt[1]);
                Photo3D.addTri(tbuf, counts, bt[0], bt[3], bt[2]);
                if (!m[cy * W + cx + 1]) { Photo3D.wall(tbuf, counts, bt[1], bt[2], tp[2], tp[1]); Photo3D.link(nb, p10, p11); }
                if (!m[cy * W + cx - 1]) { Photo3D.wall(tbuf, counts, bt[3], bt[0], tp[0], tp[3]); Photo3D.link(nb, p01, p00); }
                if (!m[(cy + 1) * W + cx]) { Photo3D.wall(tbuf, counts, bt[2], bt[3], tp[3], tp[2]); Photo3D.link(nb, p11, p01); }
                if (!m[(cy - 1) * W + cx]) { Photo3D.wall(tbuf, counts, bt[0], bt[1], tp[1], tp[0]); Photo3D.link(nb, p00, p10); }
            }
        int nv = counts[0], nt = counts[1];
        double[] v = vbuf[0];
        if (smooth > 0) {
            double[] orig = Arrays.copyOf(v, nv * 3);
            Photo3D.smoothOutline(v, topId, botId, nb, cw, ch, smooth);
            boolean[] isTop = new boolean[nv];
            for (int id : topId) if (id >= 0) isTop[id] = true;
            Photo3D.unflip(v, orig, tbuf[0], nt, isTop);
        }
        // в миллиметры; задняя точка — на Z=0 (как у рельефа), чтобы поставить через standing()
        double minZ = 1e18;
        for (int i = 0; i < nv; i++) minZ = Math.min(minZ, v[i * 3 + 2]);
        double[] vv = new double[nv * 3];
        for (int i = 0; i < nv; i++) {
            vv[i * 3] = v[i * 3] * cell;
            vv[i * 3 + 1] = v[i * 3 + 1] * cell;
            vv[i * 3 + 2] = (v[i * 3 + 2] - minZ) * cell;
        }
        Mesh body = new Mesh(vv, Arrays.copyOf(tbuf[0], nt * 3), color, "Фигурка");
        return Photo3D.standing(body, null, color);
    }

    /** Высоты лицевой и обратной поверхности в углу сетки; на кромке они сходятся (с минимальной толщиной). */
    private static double[] corner(double[] zf, double[] zb, boolean[] m, int W, int H, int cx, int cy, double t0) {
        double sf = 0, sb = 0;
        int k = 0;
        for (int dy = -1; dy <= 0; dy++)
            for (int dx = -1; dx <= 0; dx++) {
                int x = cx + dx, y = cy + dy;
                if (x >= 0 && y >= 0 && x < W && y < H && m[y * W + x]) { sf += zf[y * W + x]; sb += zb[y * W + x]; k++; }
            }
        double f = sf / k, b = sb / k, mid = (f + b) / 2;
        if (k < 4) {   // кромка: поверхности почти сходятся
            double half = Math.max(t0 / 2, 0.08 * (f - b) / 2);
            return new double[]{mid + half, mid - half};
        }
        if (f - b < t0) return new double[]{mid + t0 / 2, mid - t0 / 2};
        return new double[]{f, b};
    }
}
