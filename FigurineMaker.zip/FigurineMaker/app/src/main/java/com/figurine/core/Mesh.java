package com.figurine.core;

/** Треугольная сетка: вершины xyz подряд (double), треугольники — тройки индексов. Z — вверх, единицы — мм. */
public final class Mesh {
    public final double[] v;
    public final int[] t;
    public final int color;      // 0xRRGGBB
    public final String name;

    public Mesh(double[] v, int[] t, int color, String name) {
        this.v = v;
        this.t = t;
        this.color = color;
        this.name = name;
    }

    public int vertexCount() { return v.length / 3; }
    public int triangleCount() { return t.length / 3; }

    /** Объём по знаковым тетраэдрам. Положительный — нормали смотрят наружу. */
    public double signedVolume() {
        double vol = 0;
        for (int i = 0; i < t.length; i += 3) {
            int a = t[i] * 3, b = t[i + 1] * 3, c = t[i + 2] * 3;
            double ax = v[a], ay = v[a + 1], az = v[a + 2];
            double bx = v[b], by = v[b + 1], bz = v[b + 2];
            double cx = v[c], cy = v[c + 1], cz = v[c + 2];
            vol += ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx);
        }
        return vol / 6.0;
    }

    /**
     * Сетка «водонепроницаемая»: каждое ребро входит ровно в два треугольника, в противоположных
     * направлениях (значит, поверхность замкнута и ориентирована одинаково). Вершины сравниваются по индексам.
     * Возвращает null, если всё хорошо, иначе описание проблемы.
     */
    public String checkClosed() {
        java.util.HashMap<Long, Integer> dir = new java.util.HashMap<>();
        int n = vertexCount();
        for (int i = 0; i < t.length; i += 3) {
            for (int k = 0; k < 3; k++) {
                int a = t[i + k], b = t[i + (k + 1) % 3];
                if (a == b) return "вырожденное ребро в треугольнике " + (i / 3);
                if (a < 0 || b < 0 || a >= n || b >= n) return "индекс вне диапазона";
                long key = (long) a * n + b;
                if (dir.containsKey(key)) return "направленное ребро " + a + "->" + b + " встречается дважды";
                dir.put(key, 1);
            }
        }
        for (java.util.Map.Entry<Long, Integer> e : dir.entrySet()) {
            long key = e.getKey();
            int a = (int) (key / n), b = (int) (key % n);
            if (!dir.containsKey((long) b * n + a)) return "ребро " + a + "->" + b + " без пары (дыра)";
        }
        return null;
    }
}
