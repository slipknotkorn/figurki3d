package com.figurine.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Экспорт в STL (бинарный) и 3MF. Единицы — мм. */
public final class Exporters {
    private Exporters() {}

    /** Параметры размещения на столе: масштаб до нужной высоты, центр по XY в нуле, низ на Z=0. */
    public static final class Placement {
        public final double scale, dx, dy, dz;
        Placement(double scale, double dx, double dy, double dz) { this.scale = scale; this.dx = dx; this.dy = dy; this.dz = dz; }
        public double[] apply(double x, double y, double z) {
            return new double[]{x * scale + dx, y * scale + dy, z * scale + dz};
        }
    }

    /** targetHeightMm <= 0 — не менять масштаб. */
    public static Placement place(List<Mesh> meshes, double targetHeightMm) {
        double[] b = Figure.bounds(meshes);
        double h = b[5] - b[2];
        double s = (targetHeightMm > 0 && h > 1e-9) ? targetHeightMm / h : 1.0;
        return new Placement(s, -(b[0] + b[3]) / 2 * s, -(b[1] + b[4]) / 2 * s, -b[2] * s);
    }

    private static double[] transformed(Mesh m, Placement p) {
        double[] out = new double[m.v.length];
        for (int i = 0; i < m.v.length; i += 3) {
            double[] q = p.apply(m.v[i], m.v[i + 1], m.v[i + 2]);
            out[i] = q[0]; out[i + 1] = q[1]; out[i + 2] = q[2];
        }
        return out;
    }

    // ---------- STL ----------

    public static byte[] stl(List<Mesh> meshes, double targetHeightMm) {
        Placement pl = place(meshes, targetHeightMm);
        int tris = 0;
        for (Mesh m : meshes) tris += m.triangleCount();
        ByteBuffer bb = ByteBuffer.allocate(84 + 50 * tris).order(ByteOrder.LITTLE_ENDIAN);
        byte[] header = "Figurine Maker binary STL (mm)".getBytes(StandardCharsets.US_ASCII);
        bb.put(header);
        for (int i = header.length; i < 80; i++) bb.put((byte) 0);
        bb.putInt(tris);
        for (Mesh m : meshes) {
            double[] v = transformed(m, pl);
            for (int i = 0; i < m.t.length; i += 3) {
                int a = m.t[i] * 3, b = m.t[i + 1] * 3, c = m.t[i + 2] * 3;
                double ux = v[b] - v[a], uy = v[b + 1] - v[a + 1], uz = v[b + 2] - v[a + 2];
                double wx = v[c] - v[a], wy = v[c + 1] - v[a + 1], wz = v[c + 2] - v[a + 2];
                double nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
                double len = Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len > 0) { nx /= len; ny /= len; nz /= len; }
                bb.putFloat((float) nx).putFloat((float) ny).putFloat((float) nz);
                bb.putFloat((float) v[a]).putFloat((float) v[a + 1]).putFloat((float) v[a + 2]);
                bb.putFloat((float) v[b]).putFloat((float) v[b + 1]).putFloat((float) v[b + 2]);
                bb.putFloat((float) v[c]).putFloat((float) v[c + 1]).putFloat((float) v[c + 2]);
                bb.putShort((short) 0);
            }
        }
        return bb.array();
    }

    // ---------- 3MF ----------

    /**
     * 3MF по базовой спецификации: каждая деталь — отдельный объект с цветом (basematerials),
     * все они собраны в один составной объект, который идёт в build.
     */
    public static byte[] threeMf(List<Mesh> meshes, double targetHeightMm, String title) {
        Placement pl = place(meshes, targetHeightMm);
        StringBuilder x = new StringBuilder(1 << 16);
        x.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        x.append("<model unit=\"millimeter\" xml:lang=\"en-US\" xmlns=\"http://schemas.microsoft.com/3dmanufacturing/core/2015/02\">\n");
        x.append("<metadata name=\"Title\">").append(esc(title)).append("</metadata>\n");
        x.append("<metadata name=\"Application\">Figurine Maker</metadata>\n");
        x.append("<resources>\n<basematerials id=\"1\">\n");
        for (int i = 0; i < meshes.size(); i++) {
            x.append(String.format(Locale.ROOT, "<base name=\"%s\" displaycolor=\"#%06XFF\"/>\n",
                    esc("color" + i), meshes.get(i).color & 0xFFFFFF));
        }
        x.append("</basematerials>\n");
        int firstId = 2;
        for (int i = 0; i < meshes.size(); i++) {
            Mesh m = meshes.get(i);
            double[] v = transformed(m, pl);
            x.append("<object id=\"").append(firstId + i).append("\" type=\"model\" name=\"").append(esc(m.name))
                    .append("\" pid=\"1\" pindex=\"").append(i).append("\">\n<mesh>\n<vertices>\n");
            for (int k = 0; k < v.length; k += 3)
                x.append(String.format(Locale.ROOT, "<vertex x=\"%.4f\" y=\"%.4f\" z=\"%.4f\"/>\n", v[k], v[k + 1], v[k + 2]));
            x.append("</vertices>\n<triangles>\n");
            for (int k = 0; k < m.t.length; k += 3)
                x.append("<triangle v1=\"").append(m.t[k]).append("\" v2=\"").append(m.t[k + 1])
                        .append("\" v3=\"").append(m.t[k + 2]).append("\"/>\n");
            x.append("</triangles>\n</mesh>\n</object>\n");
        }
        int rootId = firstId + meshes.size();
        x.append("<object id=\"").append(rootId).append("\" type=\"model\" name=\"").append(esc(title)).append("\">\n<components>\n");
        for (int i = 0; i < meshes.size(); i++) x.append("<component objectid=\"").append(firstId + i).append("\"/>\n");
        x.append("</components>\n</object>\n</resources>\n");
        x.append("<build>\n<item objectid=\"").append(rootId).append("\"/>\n</build>\n</model>\n");

        String types = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"model\" ContentType=\"application/vnd.ms-package.3dmanufacturing-3dmodel+xml\"/>"
                + "</Types>";
        String rels = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Target=\"/3D/3dmodel.model\" Id=\"rel0\" Type=\"http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel\"/>"
                + "</Relationships>";
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ZipOutputStream zip = new ZipOutputStream(bos);
            put(zip, "[Content_Types].xml", types);
            put(zip, "_rels/.rels", rels);
            put(zip, "3D/3dmodel.model", x.toString());
            zip.close();
            return bos.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    private static void put(ZipOutputStream z, String name, String content) throws IOException {
        z.putNextEntry(new ZipEntry(name));
        z.write(content.getBytes(StandardCharsets.UTF_8));
        z.closeEntry();
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
