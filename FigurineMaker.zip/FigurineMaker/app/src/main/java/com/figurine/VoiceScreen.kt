package com.figurine

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.figurine.core.AiModel
import com.figurine.core.Exporters
import com.figurine.core.Mesh
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val V_WHITE = 0xF2F2F2
private const val V_BLACK = 0x4D4D4D

/**
 * Русский → английский: бесплатный онлайн-переводчик Pollinations (без ключей).
 * Встроенный переводчик Google весил ~60 МБ, поэтому от него отказались. Не в UI-потоке.
 */
private fun toEnglish(text: String): String {
    val q = "Translate to English. Reply with the translation only, no quotes: $text"
    val url = "https://text.pollinations.ai/" +
        java.net.URLEncoder.encode(q, "UTF-8").replace("+", "%20") + "?model=openai"
    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 15000
    c.readTimeout = 30000
    if (c.responseCode != 200) throw IllegalStateException("перевод недоступен")
    val en = c.inputStream.bufferedReader().use { it.readText() }.trim().trim('"')
    if (en.isEmpty() || en.length > 400) throw IllegalStateException("плохой перевод")
    return en
}

/** Вкладка «Голосом»: описание → картинка → 3D-фигурка. Всё бесплатно. */
@Composable
internal fun VoiceScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var picture by remember { mutableStateOf<ImageBitmap?>(null) }
    var raw by remember { mutableStateOf<Mesh?>(null) }
    var full by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var preview by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var black by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var sizeText by remember { mutableStateOf("80") }
    var pending by remember { mutableStateOf<ByteArray?>(null) }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val said = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) text = said
        }
    }

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val data = pending
        if (uri != null && data != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                Toast.makeText(ctx, "Файл сохранён", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Не удалось сохранить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        pending = null
    }

    LaunchedEffect(raw, black) {
        val r = raw
        if (r == null) {
            full = emptyList(); preview = emptyList()
        } else {
            val c = if (black) V_BLACK else V_WHITE
            val f = withContext(Dispatchers.Default) { AiModel.standing(r, 80.0, c) }
            full = f
            preview = withContext(Dispatchers.Default) { listOf(AiModel.simplify(f[0], 90), f[1]) }
        }
    }

    fun create() {
        val ru = text.trim()
        if (ru.isEmpty()) return
        busy = true
        raw = null
        picture = null
        scope.launch {
            try {
                status = "Перевожу описание…"
                val en = withContext(Dispatchers.IO) {
                    try { toEnglish(ru) } catch (e: Exception) { ru }   // без перевода нейросеть поймёт хуже, но попробует
                }
                val prompt = "$en, a single figurine, full body, centered, plain white background, " +
                    "soft studio light, simple clean shapes, 3d render"
                val imgBytes = withContext(Dispatchers.IO) { HfAi.textToImage(prompt) { s -> scope.launch { status = s } } }
                // показываем картинку и готовим JPEG для 3D-нейросети
                val jpeg = withContext(Dispatchers.Default) {
                    val bmp = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.size)
                        ?: throw IllegalStateException("Не удалось прочитать картинку")
                    picture = bmp.asImageBitmap()
                    val o = java.io.ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 92, o)
                    o.toByteArray()
                }
                val glb = withContext(Dispatchers.IO) { HfAi.generate(jpeg) { s -> scope.launch { status = s } } }
                status = "Обрабатываю модель…"
                raw = withContext(Dispatchers.Default) { AiModel.readGlb(glb) }
                status = ""
            } catch (e: Exception) {
                status = e.message ?: "Не получилось, попробуйте ещё раз"
            } finally {
                busy = false
            }
        }
    }

    Column(modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            "Скажите или напишите, какую фигурку хотите — например: «котёнок сидит с рыбкой» " +
                "или «рыцарь с мечом». Нейросеть нарисует её и сделает 3D-модель для печати.",
            fontSize = 13.sp,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Опишите фигурку")
                try { speech.launch(i) } catch (e: Exception) {
                    Toast.makeText(ctx, "Голосовой ввод недоступен — напишите текстом", Toast.LENGTH_LONG).show()
                }
            }, enabled = !busy) { Text("🎤 Сказать") }
            Button(onClick = { create() }, enabled = !busy && text.isNotBlank(), modifier = Modifier.weight(1f)) {
                Text(if (busy) "Создаю…" else "Создать фигурку")
            }
        }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Описание фигурки") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3,
        )
        if (status.isNotEmpty()) Text(status, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)

        Row(
            Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val pic = picture
            if (pic != null) {
                Box(Modifier.weight(0.4f).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Image(bitmap = pic, contentDescription = "Картинка от нейросети", modifier = Modifier.fillMaxWidth())
                }
            }
            Preview(meshes = preview, selected = -1, onPick = {}, modifier = Modifier.weight(0.6f).fillMaxSize())
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilterChip(selected = !black, onClick = { black = false }, label = { Text("Белый") })
            FilterChip(selected = black, onClick = { black = true }, label = { Text("Чёрный") })
            Box(Modifier.weight(1f))
            Button(onClick = { showExport = true }, enabled = full.isNotEmpty()) { Text("Экспорт") }
        }
    }

    if (showExport) {
        val target = (sizeText.replace(',', '.').toDoubleOrNull() ?: 80.0).coerceIn(10.0, 250.0)
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Экспорт для Bambu Studio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sizeText,
                        onValueChange = { sizeText = it },
                        label = { Text("Большая сторона, мм") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                    Button(onClick = {
                        pending = Exporters.threeMf(full, target, "Figurine", true)
                        showExport = false
                        saver.launch("figurka.3mf")
                    }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить 3MF") }
                    OutlinedButton(onClick = {
                        pending = Exporters.stl(full, target, true)
                        showExport = false
                        saver.launch("figurka.stl")
                    }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить STL") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("Отмена") } },
        )
    }
}
