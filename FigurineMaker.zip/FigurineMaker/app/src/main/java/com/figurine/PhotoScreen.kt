package com.figurine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.figurine.core.Exporters
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.figurine.core.MultiView
import com.figurine.core.AiModel
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.figurine.core.Mesh
import com.figurine.core.Photo3D
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val MAX_SIDE = 180
private const val AI_SIDE = 1024
private const val WHITE = 0xF2F2F2
private const val BLACK = 0x4D4D4D   // в превью чуть светлее настоящего чёрного, чтобы был виден рельеф

/** jpeg — снимок до 1024 точек для нейросети (рабочая копия argb — маленькая). */
private class Photo(val w: Int, val h: Int, val argb: IntArray, val bitmap: Bitmap, val jpeg: ByteArray)

private fun decodePhoto(ctx: android.content.Context, uri: Uri): Photo? {
    return try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= AI_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = android.graphics.Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        photoOf(bmp, m)
    } catch (e: Exception) {
        null
    }
}

/** Уменьшает снимок до рабочего размера (и поворачивает по матрице, если задана). */
private fun photoOf(src: Bitmap, rotate: android.graphics.Matrix = android.graphics.Matrix()): Photo {
    // снимок для нейросети: повёрнутый, не больше 1024 точек
    val big = android.graphics.Matrix(rotate)
    val kb = minOf(1f, AI_SIDE.toFloat() / maxOf(src.width, src.height))
    big.postScale(kb, kb)
    val hi = Bitmap.createBitmap(src, 0, 0, src.width, src.height, big, true)
    val jpg = java.io.ByteArrayOutputStream()
    hi.compress(Bitmap.CompressFormat.JPEG, 90, jpg)
    // рабочая копия для выделения и силуэтов
    val k = MAX_SIDE.toFloat() / maxOf(hi.width, hi.height)
    val bmp = Bitmap.createScaledBitmap(hi, maxOf(1, (hi.width * k).toInt()), maxOf(1, (hi.height * k).toInt()), true)
        .copy(Bitmap.Config.ARGB_8888, false)
    val px = IntArray(bmp.width * bmp.height)
    bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    for (i in px.indices) px[i] = px[i] or (0xFF shl 24)
    return Photo(bmp.width, bmp.height, px, bmp, jpg.toByteArray())
}

/** Нейросетевое выделение объекта (ML Kit). Вернёт null, если модель недоступна. */
private fun runMl(photo: Photo, done: (FloatArray?) -> Unit) {
    try {
        val seg = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
        )
        seg.process(InputImage.fromBitmap(photo.bitmap, 0))
            .addOnSuccessListener { r ->
                val fb = r.foregroundConfidenceMask
                if (fb == null || fb.remaining() != photo.w * photo.h) {
                    done(null)
                } else {
                    val a = FloatArray(fb.remaining())
                    fb.get(a)
                    done(a)
                }
            }
            .addOnFailureListener { done(null) }
    } catch (e: Throwable) {
        done(null)
    }
}

private val SLOT_TITLES = listOf("Спереди", "Сбоку", "Сверху")
private val SLOT_HINTS = listOf("обязательно", "передом вправо", "передом вниз")

/** Выделение объекта на одном фото: нейросеть, если доступна, иначе обычное по фону. */
private fun maskOf(p: Photo, conf: FloatArray?): BooleanArray =
    if (conf != null) Photo3D.fromConfidence(conf, p.w, p.h, 0.5, false)
    else Photo3D.segment(p.argb, p.w, p.h, 0.5, false)

@Composable
internal fun PhotoScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    // три места под фото: 0 — спереди (обязательно), 1 — сбоку, 2 — сверху
    var photos by remember { mutableStateOf(listOf<Photo?>(null, null, null)) }
    var masks by remember { mutableStateOf(listOf<BooleanArray?>(null, null, null)) }
    var slot by remember { mutableStateOf(0) }            // для какого места сейчас снимаем/выбираем
    var status by remember { mutableStateOf("") }
    var black by remember { mutableStateOf(false) }       // цвет пластика: белый или чёрный
    var meshes by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var showExport by remember { mutableStateOf(false) }
    var sizeText by remember { mutableStateOf("80") }
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    // нейросеть: сырая модель, готовая к печати и упрощённая для превью
    var aiRaw by remember { mutableStateOf<Mesh?>(null) }
    var aiFull by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var aiPreview by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var aiBusy by remember { mutableStateOf(false) }
    var useAi by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun accept(i: Int, p: Photo?) {
        if (p == null) {
            Toast.makeText(ctx, "Не удалось открыть фото", Toast.LENGTH_LONG).show()
            return
        }
        photos = photos.toMutableList().also { it[i] = p }
        masks = masks.toMutableList().also { it[i] = null }
        if (i == 0) { aiRaw = null; useAi = false }   // новое фото спереди — старая модель нейросети не подходит
        status = "Выделяю объект…"
        runMl(p) { c ->
            if (photos[i] === p) {   // фото не успели заменить
                masks = masks.toMutableList().also { it[i] = maskOf(p, c) }
            }
            status = ""
        }
    }

    fun clear(i: Int) {
        photos = photos.toMutableList().also { it[i] = null }
        masks = masks.toMutableList().also { it[i] = null }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) accept(slot, decodePhoto(ctx, uri))
    }
    // Съёмка камерой в полном разрешении (файл в кэше приложения, поворот по EXIF)
    val shotUri = remember {
        val dir = java.io.File(ctx.cacheDir, "shots").apply { mkdirs() }
        androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", java.io.File(dir, "shot.jpg"))
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok: Boolean ->
        if (ok) accept(slot, decodePhoto(ctx, shotUri))
    }

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val data = pending
        if (uri != null && data != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                Toast.makeText(ctx, "Файл сохранён", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Не удалось сохранить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        pending = null
    }

    // модель по всем имеющимся фото (параметры подобраны автоматически)
    LaunchedEffect(photos, masks, black) {
        val fp = photos[0]
        val fm = masks[0]
        if (fp == null || fm == null) {
            meshes = emptyList()
        } else {
            val sp = photos[1]; val sm = masks[1]
            val tp = photos[2]; val tm = masks[2]
            val c = if (black) BLACK else WHITE
            meshes = withContext(Dispatchers.Default) {
                MultiView.build(
                    fm, fp.argb, fp.w, fp.h,
                    if (sp != null) sm else null, sp?.w ?: 0, sp?.h ?: 0,
                    if (tp != null) tm else null, tp?.w ?: 0, tp?.h ?: 0,
                    80.0, 0.5, 0.7, c
                ) ?: emptyList()
            }
        }
    }

    LaunchedEffect(aiRaw, black) {
        val raw = aiRaw
        if (raw == null) {
            aiFull = emptyList(); aiPreview = emptyList()
        } else {
            val c = if (black) BLACK else WHITE
            val full = withContext(Dispatchers.Default) { AiModel.standing(raw, 80.0, c) }
            aiFull = full
            aiPreview = withContext(Dispatchers.Default) { listOf(AiModel.simplify(full[0], 90), full[1]) }
        }
    }

    fun runAi() {
        val fp = photos[0] ?: return
        aiBusy = true
        scope.launch {
            try {
                val glb = withContext(Dispatchers.IO) {
                    HfAi.generate(fp.jpeg) { s -> scope.launch { status = s } }
                }
                status = "Обрабатываю модель…"
                aiRaw = withContext(Dispatchers.Default) { AiModel.readGlb(glb) }
                useAi = true
                status = ""
            } catch (e: Exception) {
                status = e.message ?: "Нейросеть не смогла построить модель"
            } finally {
                aiBusy = false
            }
        }
    }

    // что показываем и что печатаем
    val showAi = useAi && aiFull.isNotEmpty()
    val viewMeshes = if (showAi) aiPreview else meshes
    val printMeshes = if (showAi) aiFull else meshes

    Column(modifier.fillMaxSize()) {

        // три места под фото
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (i in 0..2) {
                Column(
                    Modifier
                        .weight(1f)
                        .background(Color(0xFFF1F2F6), RoundedCornerShape(12.dp))
                        .padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(SLOT_TITLES[i], fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(SLOT_HINTS[i], fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                    val p = photos[i]
                    val m = masks[i]
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(84.dp)
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (p != null) {
                            val shown = remember(p, m) { maskedBitmap(p, m) }
                            Image(bitmap = shown, contentDescription = SLOT_TITLES[i], modifier = Modifier.fillMaxSize())
                        } else {
                            Text("нет фото", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                    TextButton(onClick = {
                        slot = i
                        try { camera.launch(shotUri) } catch (e: Exception) {
                            Toast.makeText(ctx, "Камера недоступна", Toast.LENGTH_LONG).show()
                        }
                    }) { Text("Снять", fontSize = 13.sp) }
                    TextButton(onClick = { slot = i; picker.launch("image/*") }) { Text("Из галереи", fontSize = 13.sp) }
                    if (i > 0 && p != null) TextButton(onClick = { clear(i) }) { Text("Убрать", fontSize = 12.sp) }
                }
            }
        }

        if (status.isNotEmpty()) {
            Text(status, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 12.dp))
        }

        if (photos[0] == null) {
            Text(
                "Сфотографируйте предмет спереди на ровном однотонном фоне. Фото сбоку и сверху " +
                    "необязательны, но с ними фигурка получается по-настоящему объёмной и похожей.",
                fontSize = 13.sp,
                modifier = Modifier.padding(12.dp),
            )
        } else if (masks[0] != null && meshes.isEmpty()) {
            Text(
                "Не получилось выделить предмет — переснимите на более однотонном фоне.",
                fontSize = 13.sp,
                modifier = Modifier.padding(12.dp),
            )
        }

        if (aiFull.isNotEmpty()) {
            Row(
                Modifier.padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(selected = !useAi, onClick = { useAi = false }, label = { Text("По силуэтам") })
                FilterChip(selected = useAi, onClick = { useAi = true }, label = { Text("Нейросеть") })
            }
        }

        Preview(
            meshes = viewMeshes,
            selected = -1,
            onPick = {},
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(top = 6.dp),
        )

        ScanButtons(
            aiEnabled = photos[0] != null,
            aiBusy = aiBusy,
            onAi = { runAi() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilterChip(selected = !black, onClick = { black = false }, label = { Text("Белый") })
            FilterChip(selected = black, onClick = { black = true }, label = { Text("Чёрный") })
            Box(Modifier.weight(1f))
            Button(onClick = { showExport = true }, enabled = printMeshes.isNotEmpty()) { Text("Экспорт") }
        }
    }

    if (showExport) {
        val target = (sizeText.replace(',', '.').toDoubleOrNull() ?: 80.0).coerceIn(10.0, 250.0)
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Экспорт для Bambu Studio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sizeText,
                        onValueChange = { sizeText = it },
                        label = { Text("Большая сторона, мм") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                    Text(
                        "Фигурка печатается одним цветом (" + (if (black) "чёрный" else "белый") +
                            ") и стоит на подставке. STL открывается в любом слайсере, 3MF сразу хранит цвет.",
                        fontSize = 12.sp,
                    )
                    Button(
                        onClick = {
                            pending = Exporters.threeMf(printMeshes, target, "Figurine", true)
                            showExport = false
                            saver.launch("figurka.3mf")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить 3MF") }
                    OutlinedButton(
                        onClick = {
                            pending = Exporters.stl(printMeshes, target, true)
                            showExport = false
                            saver.launch("figurka.stl")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить STL") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("Отмена") } },
        )
    }
}

/** Фото с затемнённым фоном — видно, что именно выделено. */
private fun maskedBitmap(p: Photo, m: BooleanArray?): androidx.compose.ui.graphics.ImageBitmap {
    val out = IntArray(p.argb.size)
    for (i in out.indices) {
        val c = p.argb[i]
        out[i] = if (m == null || m[i]) c else {
            val r = ((c shr 16) and 255) / 4
            val g = ((c shr 8) and 255) / 4
            val b = (c and 255) / 4
            (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
    return Bitmap.createBitmap(out, p.w, p.h, Bitmap.Config.ARGB_8888).asImageBitmap()
}
