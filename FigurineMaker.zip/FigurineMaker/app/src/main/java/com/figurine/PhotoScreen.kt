package com.figurine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.figurine.core.Exporters
import com.figurine.core.Mesh
import com.figurine.core.Photo3D
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val MAX_SIDE = 180
private const val WHITE = 0xF2F2F2
private const val BLACK = 0x202020

private class Photo(val w: Int, val h: Int, val argb: IntArray, val bitmap: Bitmap)

private fun decodePhoto(ctx: android.content.Context, uri: Uri): Photo? {
    return try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = android.graphics.Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        val k = MAX_SIDE.toFloat() / maxOf(bmp.width, bmp.height)
        m.postScale(k, k)
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        for (i in px.indices) px[i] = px[i] or (0xFF shl 24)
        Photo(bmp.width, bmp.height, px, bmp)
    } catch (e: Exception) {
        null
    }
}

/** Нейросетевое выделение объекта (ML Kit). Вернёт null, если модель недоступна. */
private fun runMl(photo: Photo, done: (FloatArray?) -> Unit) {
    try {
        val seg = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
        )
        seg.process(InputImage.fromBitmap(photo.bitmap, 0))
            .addOnSuccessListener { r ->
                val fb = r.foregroundConfidenceMask
                if (fb == null || fb.remaining() != photo.w * photo.h) {
                    done(null)
                } else {
                    val a = FloatArray(fb.remaining())
                    fb.get(a)
                    done(a)
                }
            }
            .addOnFailureListener { done(null) }
    } catch (e: Throwable) {
        done(null)
    }
}

@Composable
internal fun PhotoScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var photo by remember { mutableStateOf<Photo?>(null) }
    var conf by remember { mutableStateOf<FloatArray?>(null) }
    var useMl by remember { mutableStateOf(true) }
    var mlNote by remember { mutableStateOf("") }
    var invert by remember { mutableStateOf(false) }
    var sens by remember { mutableFloatStateOf(0.5f) }
    var size by remember { mutableFloatStateOf(80f) }
    var thick by remember { mutableFloatStateOf(0.3f) }   // толщина как доля размера
    var detail by remember { mutableFloatStateOf(0.5f) }
    var inkOn by remember { mutableStateOf(true) }
    var inkLevel by remember { mutableFloatStateOf(0.3f) }
    var standing by remember { mutableStateOf(true) }
    var mask by remember { mutableStateOf<BooleanArray?>(null) }
    var meshes by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var showExport by remember { mutableStateOf(false) }
    var sizeText by remember { mutableStateOf("80") }
    var pending by remember { mutableStateOf<ByteArray?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val p = decodePhoto(ctx, uri)
            if (p == null) {
                Toast.makeText(ctx, "Не удалось открыть фото", Toast.LENGTH_LONG).show()
            } else {
                photo = p
                conf = null
                mlNote = "Нейросеть: считаю…"
                runMl(p) { c ->
                    conf = c
                    mlNote = if (c == null) "Нейросеть недоступна — использую обычное выделение" else "Нейросеть: готово"
                }
            }
        }
    }

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val data = pending
        if (uri != null && data != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                Toast.makeText(ctx, "Файл сохранён", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Не удалось сохранить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        pending = null
    }

    // маска
    LaunchedEffect(photo, conf, useMl, sens, invert) {
        val p = photo
        if (p == null) {
            mask = null
        } else {
            val c = conf
            mask = withContext(Dispatchers.Default) {
                if (useMl && c != null) Photo3D.fromConfidence(c, p.w, p.h, 0.5, invert)
                else Photo3D.segment(p.argb, p.w, p.h, sens.toDouble(), invert)
            }
        }
    }

    // модель
    LaunchedEffect(photo, mask, size, thick, detail, inkOn, inkLevel, standing) {
        val p = photo
        val m = mask
        if (p == null || m == null) {
            meshes = emptyList()
        } else {
            meshes = withContext(Dispatchers.Default) {
                val r = Photo3D.build(
                    m, p.argb, p.w, p.h, size.toDouble(), (size * thick).toDouble(),
                    detail.toDouble(), if (inkOn) inkLevel.toDouble() else -1.0,
                    0.6, WHITE, BLACK, "Фигурка"
                )
                if (r == null) emptyList()
                else if (standing) Photo3D.standing(r[0], r[1], WHITE)
                else listOfNotNull(r[0], r[1])
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = { picker.launch("image/*") }) { Text(if (photo == null) "Выбрать фото" else "Другое фото") }
            Button(onClick = { showExport = true }, enabled = meshes.isNotEmpty()) { Text("Экспорт") }
        }

        val p = photo
        if (p == null) {
            Text(
                "Выберите фотографию предмета или игрушки на ровном фоне. Приложение само выделит объект " +
                    "и сделает чёрно-белую фигурку: белое тело и чёрные детали по тёмным местам фото. " +
                    "С одной фото получается объёмный рельеф с точным контуром, а не полная 3D-копия.",
                fontSize = 14.sp,
                modifier = Modifier.padding(12.dp),
            )
            return@Column
        }

        Row(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val m = mask
            val shown = remember(p, m) {
                val out = IntArray(p.argb.size)
                for (i in out.indices) {
                    val c = p.argb[i]
                    out[i] = if (m != null && m[i]) c else {
                        val r = ((c shr 16) and 255) / 4
                        val g = ((c shr 8) and 255) / 4
                        val b = (c and 255) / 4
                        (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                Bitmap.createBitmap(out, p.w, p.h, Bitmap.Config.ARGB_8888).asImageBitmap()
            }
            Image(
                bitmap = shown,
                contentDescription = "Выделенный объект",
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
            )
            Preview(
                meshes = meshes,
                selected = -1,
                onPick = {},
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (mlNote.isNotEmpty()) Text(mlNote, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = useMl, onClick = { useMl = !useMl }, label = { Text("Нейросеть") })
                FilterChip(selected = invert, onClick = { invert = !invert }, label = { Text("Инвертировать") })
                FilterChip(selected = standing, onClick = { standing = !standing }, label = { Text("Стоя на подставке") })
            }
            if (mask != null && meshes.isEmpty()) {
                Text("Объект не найден — измените чувствительность или нажмите «Инвертировать».", fontSize = 13.sp)
            }
            SliderRow("Чувствительность", sens, 0f, 1f) { sens = it }
            SliderRow("Размер, мм", size, 30f, 150f) { size = it; sizeText = "%.0f".format(it) }
            SliderRow("Толщина", thick, 0.1f, 0.6f) { thick = it }
            SliderRow("Детали рельефа", detail, 0f, 1f) { detail = it }
            FilterChip(selected = inkOn, onClick = { inkOn = !inkOn }, label = { Text("Чёрные детали") })
            if (inkOn) SliderRow("Порог чёрного", inkLevel, 0.1f, 0.6f) { inkLevel = it }
        }
    }

    if (showExport) {
        val target = (sizeText.replace(',', '.').toDoubleOrNull() ?: 80.0).coerceIn(10.0, 250.0)
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Экспорт для Bambu Studio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sizeText,
                        onValueChange = { sizeText = it },
                        label = { Text("Большая сторона, мм") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                    Text(
                        "3MF — белое и чёрное как отдельные цвета (для мультицвета AMS), " +
                            "STL — одним цветом.",
                        fontSize = 12.sp,
                    )
                    Button(
                        onClick = {
                            pending = Exporters.threeMf(meshes, target, "Figurine", true)
                            showExport = false
                            saver.launch("figurka_foto.3mf")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить 3MF (с цветами)") }
                    OutlinedButton(
                        onClick = {
                            pending = Exporters.stl(meshes, target, true)
                            showExport = false
                            saver.launch("figurka_foto.stl")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить STL") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, modifier = Modifier.width(138.dp))
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            valueRange = min..max,
            modifier = Modifier.weight(1f),
        )
    }
}
