package com.figurine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.figurine.core.Exporters
import com.figurine.core.Mesh
import com.figurine.core.Photo3D
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val MAX_SIDE = 180
private const val WHITE = 0xF2F2F2
private const val BLACK = 0x4D4D4D   // в превью чуть светлее настоящего чёрного, чтобы был виден рельеф

private class Photo(val w: Int, val h: Int, val argb: IntArray, val bitmap: Bitmap)

private fun decodePhoto(ctx: android.content.Context, uri: Uri): Photo? {
    return try {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = android.graphics.Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        photoOf(bmp, m)
    } catch (e: Exception) {
        null
    }
}

/** Уменьшает снимок до рабочего размера (и поворачивает по матрице, если задана). */
private fun photoOf(src: Bitmap, rotate: android.graphics.Matrix = android.graphics.Matrix()): Photo {
    val m = android.graphics.Matrix(rotate)
    val k = MAX_SIDE.toFloat() / maxOf(src.width, src.height)
    m.postScale(k, k)
    val bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        .copy(Bitmap.Config.ARGB_8888, false)
    val px = IntArray(bmp.width * bmp.height)
    bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
    for (i in px.indices) px[i] = px[i] or (0xFF shl 24)
    return Photo(bmp.width, bmp.height, px, bmp)
}

/** Нейросетевое выделение объекта (ML Kit). Вернёт null, если модель недоступна. */
private fun runMl(photo: Photo, done: (FloatArray?) -> Unit) {
    try {
        val seg = SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
        )
        seg.process(InputImage.fromBitmap(photo.bitmap, 0))
            .addOnSuccessListener { r ->
                val fb = r.foregroundConfidenceMask
                if (fb == null || fb.remaining() != photo.w * photo.h) {
                    done(null)
                } else {
                    val a = FloatArray(fb.remaining())
                    fb.get(a)
                    done(a)
                }
            }
            .addOnFailureListener { done(null) }
    } catch (e: Throwable) {
        done(null)
    }
}

@Composable
internal fun PhotoScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var photo by remember { mutableStateOf<Photo?>(null) }
    var conf by remember { mutableStateOf<FloatArray?>(null) }
    var useMl by remember { mutableStateOf(true) }
    var mlNote by remember { mutableStateOf("") }
    var invert by remember { mutableStateOf(false) }
    var sens by remember { mutableFloatStateOf(0.5f) }
    var size by remember { mutableFloatStateOf(80f) }
    var thick by remember { mutableFloatStateOf(0.3f) }   // толщина как доля размера
    var detail by remember { mutableFloatStateOf(0.5f) }
    var black by remember { mutableStateOf(false) }   // цвет пластика: белый или чёрный
    var smooth by remember { mutableFloatStateOf(0.7f) }  // гладкость контура и поверхности
    var standing by remember { mutableStateOf(true) }
    var mask by remember { mutableStateOf<BooleanArray?>(null) }
    var meshes by remember { mutableStateOf<List<Mesh>>(emptyList()) }
    var showExport by remember { mutableStateOf(false) }
    var sizeText by remember { mutableStateOf("80") }
    var pending by remember { mutableStateOf<ByteArray?>(null) }

    fun accept(p: Photo?) {
        if (p == null) {
            Toast.makeText(ctx, "Не удалось открыть фото", Toast.LENGTH_LONG).show()
            return
        }
        photo = p
        conf = null
        mlNote = "Нейросеть: считаю…"
        runMl(p) { c ->
            conf = c
            mlNote = if (c == null) "Нейросеть недоступна — использую обычное выделение" else "Нейросеть: готово"
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) accept(decodePhoto(ctx, uri))
    }
    // Съёмка камерой в полном разрешении: камера пишет снимок в файл приложения,
    // мы читаем его с учётом поворота (EXIF) — так выделение объекта и края точнее
    val shotUri = remember {
        val dir = java.io.File(ctx.cacheDir, "shots").apply { mkdirs() }
        androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".files", java.io.File(dir, "shot.jpg"))
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok: Boolean ->
        if (ok) accept(decodePhoto(ctx, shotUri))
    }

    val saver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val data = pending
        if (uri != null && data != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                Toast.makeText(ctx, "Файл сохранён", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Не удалось сохранить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
        pending = null
    }

    // маска
    LaunchedEffect(photo, conf, useMl, sens, invert) {
        val p = photo
        if (p == null) {
            mask = null
        } else {
            val c = conf
            mask = withContext(Dispatchers.Default) {
                if (useMl && c != null) Photo3D.fromConfidence(c, p.w, p.h, 0.5, invert)
                else Photo3D.segment(p.argb, p.w, p.h, sens.toDouble(), invert)
            }
        }
    }

    // модель
    LaunchedEffect(photo, mask, size, thick, detail, black, standing, smooth) {
        val p = photo
        val m = mask
        if (p == null || m == null) {
            meshes = emptyList()
        } else {
            meshes = withContext(Dispatchers.Default) {
                val c = if (black) BLACK else WHITE
                // один цвет: без отдельного чёрного слоя, детали лица и т. п. остаются рельефом
                val r = Photo3D.build(
                    m, p.argb, p.w, p.h, size.toDouble(), (size * thick).toDouble(),
                    detail.toDouble(), -1.0, 0.6, c, c, "Фигурка", smooth.toDouble()
                )
                if (r == null) emptyList()
                else if (standing) Photo3D.standing(r[0], null, c)
                else listOf(r[0])
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(onClick = {
                try { camera.launch(shotUri) } catch (e: Exception) {
                    Toast.makeText(ctx, "Камера недоступна", Toast.LENGTH_LONG).show()
                }
            }) { Text("Сфотографировать") }
            OutlinedButton(onClick = { picker.launch("image/*") }) { Text("Из галереи") }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
        ) {
            Button(
                onClick = { showExport = true },
                enabled = meshes.isNotEmpty(),
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Экспорт для печати") }
        }

        val p = photo
        if (p == null) {
            Text(
                "Сфотографируйте предмет или игрушку на ровном фоне или выберите фото из галереи. " +
                    "Приложение само выделит объект и сделает фигурку одного цвета — белую или чёрную. " +
                    "С одной фото получается объёмный рельеф с точным контуром, а не полная 3D-копия.",
                fontSize = 14.sp,
                modifier = Modifier.padding(12.dp),
            )
            return@Column
        }

        Row(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val m = mask
            val shown = remember(p, m) {
                val out = IntArray(p.argb.size)
                for (i in out.indices) {
                    val c = p.argb[i]
                    out[i] = if (m != null && m[i]) c else {
                        val r = ((c shr 16) and 255) / 4
                        val g = ((c shr 8) and 255) / 4
                        val b = (c and 255) / 4
                        (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                Bitmap.createBitmap(out, p.w, p.h, Bitmap.Config.ARGB_8888).asImageBitmap()
            }
            Image(
                bitmap = shown,
                contentDescription = "Выделенный объект",
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
            )
            Preview(
                meshes = meshes,
                selected = -1,
                onPick = {},
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
            )
        }

        Column(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (mlNote.isNotEmpty()) Text(mlNote, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = useMl, onClick = { useMl = !useMl }, label = { Text("Нейросеть") })
                FilterChip(selected = invert, onClick = { invert = !invert }, label = { Text("Инвертировать") })
                FilterChip(selected = standing, onClick = { standing = !standing }, label = { Text("Стоя на подставке") })
            }
            if (mask != null && meshes.isEmpty()) {
                Text("Объект не найден — измените чувствительность или нажмите «Инвертировать».", fontSize = 13.sp)
            }
            SliderRow("Чувствительность", sens, 0f, 1f) { sens = it }
            SliderRow("Размер, мм", size, 30f, 150f) { size = it; sizeText = "%.0f".format(it) }
            SliderRow("Толщина", thick, 0.1f, 0.6f) { thick = it }
            SliderRow("Детали рельефа", detail, 0f, 1f) { detail = it }
            SliderRow("Гладкость", smooth, 0f, 1f) { smooth = it }
            Text("Цвет пластика", fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = !black, onClick = { black = false }, label = { Text("Белый") })
                FilterChip(selected = black, onClick = { black = true }, label = { Text("Чёрный") })
            }
        }
    }

    if (showExport) {
        val target = (sizeText.replace(',', '.').toDoubleOrNull() ?: 80.0).coerceIn(10.0, 250.0)
        AlertDialog(
            onDismissRequest = { showExport = false },
            title = { Text("Экспорт для Bambu Studio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sizeText,
                        onValueChange = { sizeText = it },
                        label = { Text("Большая сторона, мм") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                    Text(
                        "Фигурка печатается одним цветом (" + (if (black) "чёрный" else "белый") +
                            "). STL открывается в Bambu Studio и любом слайсере, 3MF сразу хранит цвет.",
                        fontSize = 12.sp,
                    )
                    Button(
                        onClick = {
                            pending = Exporters.threeMf(meshes, target, "Figurine", true)
                            showExport = false
                            saver.launch("figurka_foto.3mf")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить 3MF") }
                    OutlinedButton(
                        onClick = {
                            pending = Exporters.stl(meshes, target, true)
                            showExport = false
                            saver.launch("figurka_foto.stl")
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Сохранить STL") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showExport = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun SliderRow(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, modifier = Modifier.width(138.dp))
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            valueRange = min..max,
            modifier = Modifier.weight(1f),
        )
    }
}
