package com.figurine.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Фигурка = список деталей-примитивов. Единицы — мм, Z — вверх. */
public final class Figure {

    /** Одна деталь: примитив + положение, размеры (габариты по осям, мм), поворот (градусы), цвет. */
    public static final class Part {
        public int shape;
        public String name;
        public double px, py, pz;
        public double sx = 20, sy = 20, sz = 20;
        public double rx, ry, rz;
        public int color = 0xE0E0E0;

        public Part(int shape, String name, double px, double py, double pz,
                    double sx, double sy, double sz, int color) {
            this.shape = shape; this.name = name;
            this.px = px; this.py = py; this.pz = pz;
            this.sx = sx; this.sy = sy; this.sz = sz;
            this.color = color;
        }

        public Part rot(double rx, double ry, double rz) { this.rx = rx; this.ry = ry; this.rz = rz; return this; }

        public Part copy() {
            Part p = new Part(shape, name, px, py, pz, sx, sy, sz, color);
            p.rx = rx; p.ry = ry; p.rz = rz;
            return p;
        }

        /** Зеркальная копия относительно плоскости YZ (x -> -x). Поворот пересчитан так, что сетка остаётся правильной. */
        public Part mirrored() {
            Part p = copy();
            p.px = -px;
            p.ry = -ry;
            p.rz = -rz;
            p.name = name + " (зерк.)";
            return p;
        }
    }

    public final List<Part> parts = new ArrayList<>();

    public Figure copy() {
        Figure f = new Figure();
        for (Part p : parts) f.parts.add(p.copy());
        return f;
    }

    // ---------- Геометрия ----------

    /** Собирает сетки всех деталей в мировых координатах. quality — число сегментов (превью ~16, печать ~48). */
    public List<Mesh> build(int quality) {
        ArrayList<Mesh> out = new ArrayList<>();
        for (Part p : parts) out.add(buildPart(p, quality));
        return out;
    }

    public static Mesh buildPart(Part p, int quality) {
        Object[] u = Shapes.unit(p.shape, quality);
        double[] src = (double[]) u[0];
        int[] t = ((int[]) u[1]).clone();
        double sx = Math.max(0.1, p.sx), sy = Math.max(0.1, p.sy), sz = Math.max(0.1, p.sz);
        double a = Math.toRadians(p.rx), b = Math.toRadians(p.ry), c = Math.toRadians(p.rz);
        double ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b), cc = Math.cos(c), sc = Math.sin(c);
        // R = Rz * Ry * Rx
        double m00 = cc * cb, m01 = cc * sb * sa - sc * ca, m02 = cc * sb * ca + sc * sa;
        double m10 = sc * cb, m11 = sc * sb * sa + cc * ca, m12 = sc * sb * ca - cc * sa;
        double m20 = -sb,     m21 = cb * sa,                m22 = cb * ca;
        double[] v = new double[src.length];
        for (int i = 0; i < src.length; i += 3) {
            double x = src[i] * sx, y = src[i + 1] * sy, z = src[i + 2] * sz;
            v[i]     = m00 * x + m01 * y + m02 * z + p.px;
            v[i + 1] = m10 * x + m11 * y + m12 * z + p.py;
            v[i + 2] = m20 * x + m21 * y + m22 * z + p.pz;
        }
        return new Mesh(v, t, p.color, p.name);
    }

    /** {minX,minY,minZ,maxX,maxY,maxZ} по всем сеткам; для пустого списка — нули. */
    public static double[] bounds(List<Mesh> meshes) {
        double[] r = {1e18, 1e18, 1e18, -1e18, -1e18, -1e18};
        boolean any = false;
        for (Mesh m : meshes)
            for (int i = 0; i < m.v.length; i += 3) {
                any = true;
                for (int k = 0; k < 3; k++) {
                    r[k] = Math.min(r[k], m.v[i + k]);
                    r[k + 3] = Math.max(r[k + 3], m.v[i + k]);
                }
            }
        return any ? r : new double[6];
    }

    // ---------- Сохранение ----------

    public String toText() {
        StringBuilder sb = new StringBuilder("FIG1\n");
        for (Part p : parts) {
            sb.append(String.format(Locale.ROOT, "%d|%s|%.3f|%.3f|%.3f|%.3f|%.3f|%.3f|%.2f|%.2f|%.2f|%d\n",
                    p.shape, p.name.replace('|', '/').replace('\n', ' '), p.px, p.py, p.pz,
                    p.sx, p.sy, p.sz, p.rx, p.ry, p.rz, p.color));
        }
        return sb.toString();
    }

    /** Читает текст из toText(); при ошибке возвращает null. */
    public static Figure fromText(String s) {
        if (s == null) return null;
        try {
            String[] lines = s.split("\n");
            if (lines.length == 0 || !lines[0].equals("FIG1")) return null;
            Figure f = new Figure();
            for (int i = 1; i < lines.length; i++) {
                if (lines[i].trim().isEmpty()) continue;
                String[] q = lines[i].split("\\|", -1);
                if (q.length != 12) return null;
                int shape = Integer.parseInt(q[0]);
                if (shape < 0 || shape >= Shapes.NAMES.length) return null;
                Part p = new Part(shape, q[1], d(q[2]), d(q[3]), d(q[4]), d(q[5]), d(q[6]), d(q[7]), Integer.parseInt(q[11]));
                p.rx = d(q[8]); p.ry = d(q[9]); p.rz = d(q[10]);
                f.parts.add(p);
            }
            return f;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static double d(String s) { return Double.parseDouble(s); }

    // ---------- Шаблоны ----------

    public static final String[] PRESET_NAMES = {"Снеговик", "Мишка", "Пингвин", "Человечек"};

    public static Figure preset(int i) {
        switch (i) {
            case 0: return snowman();
            case 1: return bear();
            case 2: return penguin();
            default: return person();
        }
    }

    private static final int WHITE = 0xF2F2F2, BLACK = 0x222222, ORANGE = 0xF28C28, RED = 0xD93A3A,
            BROWN = 0x8B5A2B, TAN = 0xD2A679, BLUE = 0x3A6FD9, SKIN = 0xF0C8A0, YELLOW = 0xF2C230, GREEN = 0x3FA34D;

    public static Figure snowman() {
        Figure f = new Figure();
        f.parts.add(new Part(Shapes.SPHERE, "Низ", 0, 0, 14, 30, 30, 28, WHITE));
        f.parts.add(new Part(Shapes.SPHERE, "Середина", 0, 0, 34, 22, 22, 20, WHITE));
        f.parts.add(new Part(Shapes.SPHERE, "Голова", 0, 0, 49, 15, 15, 14, WHITE));
        f.parts.add(new Part(Shapes.CONE, "Нос", 0, 8.5, 49, 3, 3, 9, ORANGE).rot(-90, 0, 0));
        f.parts.add(new Part(Shapes.CYLINDER, "Шляпа: поля", 0, 0, 56, 18, 18, 1.5, BLACK));
        f.parts.add(new Part(Shapes.CYLINDER, "Шляпа", 0, 0, 61, 11, 11, 9, BLACK));
        f.parts.add(new Part(Shapes.TORUS, "Шарф", 0, 0, 42.5, 21, 21, 21, RED));
        return f;
    }

    public static Figure bear() {
        Figure f = new Figure();
        f.parts.add(new Part(Shapes.SPHERE, "Тело", 0, 0, 18, 28, 22, 30, BROWN));
        f.parts.add(new Part(Shapes.SPHERE, "Голова", 0, 0, 42, 24, 22, 20, BROWN));
        f.parts.add(new Part(Shapes.SPHERE, "Ухо", 9, 0, 51, 8, 6, 8, BROWN));
        f.parts.add(new Part(Shapes.SPHERE, "Морда", 0, 9, 40, 11, 8, 9, TAN));
        f.parts.add(new Part(Shapes.SPHERE, "Нос", 0, 12.5, 42, 4, 3, 3, BLACK));
        f.parts.add(new Part(Shapes.SPHERE, "Глаз", 5, 10, 46, 3, 2.5, 3, BLACK));
        f.parts.add(new Part(Shapes.SPHERE, "Лапа", 15, 3, 20, 9, 9, 18, BROWN).rot(0, -12, 0));
        f.parts.add(new Part(Shapes.SPHERE, "Нога", 8, 5, 4, 11, 14, 9, BROWN));
        // вторые половинки симметричных деталей — зеркальные копии
        int n = f.parts.size();
        for (int i = 2; i < n; i++) {
            Part p = f.parts.get(i);
            if (i == 3 || i == 4) continue; // морда и нос на оси
            f.parts.add(p.mirrored());
        }
        return f;
    }

    public static Figure penguin() {
        Figure f = new Figure();
        f.parts.add(new Part(Shapes.SPHERE, "Тело", 0, 0, 22, 26, 22, 42, BLACK));
        f.parts.add(new Part(Shapes.SPHERE, "Живот", 0, 4.5, 20, 19, 14, 34, WHITE));
        f.parts.add(new Part(Shapes.SPHERE, "Глаз", 4.5, 9.5, 37, 4, 3, 4.5, WHITE));
        f.parts.add(new Part(Shapes.SPHERE, "Зрачок", 4.8, 11.2, 37, 2, 1.5, 2.5, BLACK));
        f.parts.add(new Part(Shapes.CONE, "Клюв", 0, 11.5, 33, 6, 6, 8, ORANGE).rot(-90, 0, 0));
        f.parts.add(new Part(Shapes.SPHERE, "Крыло", 14, 0, 24, 5, 12, 24, BLACK).rot(0, -15, 0));
        f.parts.add(new Part(Shapes.SPHERE, "Лапа", 6, 5, 1.5, 10, 14, 3, ORANGE));
        int n = f.parts.size();
        for (int i = 2; i < n; i++) {
            if (i == 4) continue; // клюв на оси
            f.parts.add(f.parts.get(i).mirrored());
        }
        return f;
    }

    public static Figure person() {
        Figure f = new Figure();
        f.parts.add(new Part(Shapes.CYLINDER, "Подставка", 0, 0, 1.5, 34, 34, 3, 0x777777));
        f.parts.add(new Part(Shapes.CYLINDER, "Нога", 4.5, 0, 14, 7, 7, 22, BLUE));
        f.parts.add(new Part(Shapes.BOX, "Туловище", 0, 0, 34, 20, 11, 20, GREEN));
        f.parts.add(new Part(Shapes.CYLINDER, "Рука", 12.5, 0, 33, 5.5, 5.5, 18, GREEN).rot(0, -8, 0));
        f.parts.add(new Part(Shapes.SPHERE, "Кисть", 14, 0, 23.5, 5.5, 5.5, 5.5, SKIN));
        f.parts.add(new Part(Shapes.SPHERE, "Голова", 0, 0, 51, 15, 15, 16, SKIN));
        f.parts.add(new Part(Shapes.DOME, "Волосы", 0, -0.5, 54, 16, 16, 10, YELLOW));
        int n = f.parts.size();
        for (int i = 1; i < n; i++) {
            if (i == 2 || i == 5 || i == 6) continue; // на оси
            f.parts.add(f.parts.get(i).mirrored());
        }
        return f;
    }
}
