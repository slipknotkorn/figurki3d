package com.figurine

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** «Версия … · Проверить обновления» и плашка «Доступна новая версия — Обновить». */
@Composable
internal fun UpdateBar(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val current = remember { Updater.currentVersion(ctx) }
    var avail by remember { mutableStateOf<Updater.Release?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun check(manual: Boolean) {
        scope.launch {
            if (manual) status = "Проверяю…"
            try {
                val r = withContext(Dispatchers.IO) { Updater.latest() }
                if (r.version > current) {
                    avail = r
                    status = ""
                } else {
                    avail = null
                    status = if (manual) "У вас последняя версия (1.$current)" else ""
                }
            } catch (e: Exception) {
                status = if (manual) (e.message ?: "Не удалось проверить") else ""
            }
        }
    }

    fun update(r: Updater.Release) {
        if (!Updater.ensureInstallAllowed(ctx)) {
            status = "Разрешите установку из этого приложения и снова нажмите «Обновить»"
            return
        }
        scope.launch {
            busy = true
            status = "Скачиваю…"
            try {
                val f = withContext(Dispatchers.IO) {
                    Updater.download(ctx, r) { p -> scope.launch { status = "Скачиваю… $p%" } }
                }
                status = ""
                Updater.install(ctx, f)
            } catch (e: Exception) {
                status = e.message ?: "Не удалось скачать"
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { check(false) }   // тихая проверка при запуске

    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val r = avail
        if (r != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Доступна версия 1.${r.version}",
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
                Button(onClick = { update(r) }, enabled = !busy) { Text("Обновить") }
            }
        }
        if (status.isNotEmpty()) Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Версия 1.$current", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline, modifier = Modifier.weight(1f))
            TextButton(onClick = { check(true) }, enabled = !busy) { Text("Проверить обновления", fontSize = 13.sp) }
        }
    }
}
