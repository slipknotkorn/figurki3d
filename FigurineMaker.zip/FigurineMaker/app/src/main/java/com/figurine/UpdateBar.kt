package com.figurine

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** «Версия … · Проверить обновления» и плашка «Доступна новая версия — Обновить». */
@Composable
internal fun UpdateBar(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val current = remember { Updater.currentVersion(ctx) }
    var avail by remember { mutableStateOf<Updater.Release?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun check(manual: Boolean) {
        scope.launch {
            if (manual) status = "Проверяю…"
            try {
                val r = withContext(Dispatchers.IO) { Updater.latest() }
                if (r.version > current) {
                    avail = r
                    status = ""
                } else {
                    avail = null
                    status = if (manual) "У вас последняя версия (1.$current)" else ""
                }
            } catch (e: Exception) {
                status = if (manual) (e.message ?: "Не удалось проверить") else ""
            }
        }
    }

    fun update(r: Updater.Release) {
        if (!Updater.ensureInstallAllowed(ctx)) {
            status = "Разрешите установку из этого приложения и снова нажмите «Обновить»"
            return
        }
        scope.launch {
            busy = true
            status = "Скачиваю…"
            try {
                val f = withContext(Dispatchers.IO) {
                    Updater.download(ctx, r) { p -> scope.launch { status = "Скачиваю… $p%" } }
                }
                status = ""
                Updater.install(ctx, f)
            } catch (e: Exception) {
                status = e.message ?: "Не удалось скачать"
            } finally {
                busy = false
            }
        }
    }

    // проверка при запуске и потом каждые 15 минут, пока приложение открыто
    LaunchedEffect(Unit) {
        while (true) {
            check(false)
            kotlinx.coroutines.delay(15 * 60 * 1000L)
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        val r = avail
        Row(verticalAlignment = Alignment.CenterVertically) {
            // левый угол: версия, а если вышла новая — об этом
            if (r == null) {
                Text(
                    "Версия 1.$current",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { check(true) }, enabled = !busy) { Text("Проверить обновления", fontSize = 12.sp) }
            } else {
                Text(
                    "Версия 1.$current · вышла 1.${r.version}!",
                    fontSize = 14.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                )
                Button(onClick = { update(r) }, enabled = !busy, modifier = Modifier.padding(start = 8.dp)) {
                    Text(if (busy) "Скачиваю…" else "Обновить")
                }
            }
        }
        if (status.isNotEmpty()) Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
    }
}
