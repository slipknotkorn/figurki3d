# Наш код: ядро вызывается из Kotlin напрямую, но держим его целиком — так надёжнее
-keep class com.figurine.** { *; }
# Аннотации из сторонних библиотек, которых нет в рантайме Android
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.checkerframework.**
-dontwarn com.google.j2objc.annotations.**
-dontwarn org.jetbrains.annotations.**
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
