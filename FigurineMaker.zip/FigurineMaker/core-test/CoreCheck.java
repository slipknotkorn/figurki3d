import com.figurine.core.*;

import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

public class CoreCheck {
    static int fails = 0, checks = 0;

    static void ok(boolean cond, String msg) {
        checks++;
        if (!cond) { fails++; System.out.println("FAIL: " + msg); }
    }

    public static void main(String[] a) throws Exception {
        // 1. Каждый примитив: замкнут, ориентирован наружу, объём близок к формуле
        double[] analytic = {
                Math.PI / 6,                 // шар диаметра 1
                Math.PI / 4,                 // цилиндр d=1,h=1
                Math.PI / 12,                // конус
                1.0,                         // куб
                Math.PI / 6 * 1.0,           // купол: половина эллипсоида с полуосями .5,.5,1 -> 2/3*pi*.5*.5*1
                2 * Math.PI * Math.PI * 0.35 * 0.15 * 0.15 // тор
        };
        analytic[4] = (2.0 / 3.0) * Math.PI * 0.5 * 0.5 * 1.0;
        for (int shape = 0; shape < Shapes.NAMES.length; shape++) {
            for (int q : new int[]{6, 7, 16, 48}) {
                Object[] u = Shapes.unit(shape, q);
                Mesh m = new Mesh((double[]) u[0], (int[]) u[1], 0, Shapes.NAMES[shape]);
                String err = m.checkClosed();
                ok(err == null, Shapes.NAMES[shape] + " q=" + q + ": " + err);
                double vol = m.signedVolume();
                ok(vol > 0, Shapes.NAMES[shape] + " q=" + q + " объём <= 0: " + vol);
                if (q == 48) {
                    double rel = Math.abs(vol - analytic[shape]) / analytic[shape];
                    ok(rel < 0.02, Shapes.NAMES[shape] + " объём " + vol + " vs " + analytic[shape] + " (отн. ошибка " + rel + ")");
                    System.out.printf(Locale.ROOT, "  %-9s q=48: вершин %4d, треугольников %4d, объём %.5f (формула %.5f)%n",
                            Shapes.NAMES[shape], m.vertexCount(), m.triangleCount(), vol, analytic[shape]);
                }
            }
        }

        // 2. Габариты единичных примитивов
        for (int shape = 0; shape < Shapes.NAMES.length; shape++) {
            Object[] u = Shapes.unit(shape, 32);
            double[] v = (double[]) u[0];
            double[] mn = {1e9, 1e9, 1e9}, mx = {-1e9, -1e9, -1e9};
            for (int i = 0; i < v.length; i += 3) for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], v[i + k]); mx[k] = Math.max(mx[k], v[i + k]); }
            double zh = shape == Shapes.TORUS ? 0.15 : 0.5;
            ok(Math.abs(mx[2] - zh) < 1e-9 && Math.abs(mn[2] + zh) < 1e-9, Shapes.NAMES[shape] + " Z-габарит " + mn[2] + ".." + mx[2]);
            ok(Math.abs(mx[0] - 0.5) < 1e-9 && Math.abs(mn[0] + 0.5) < 1e-9, Shapes.NAMES[shape] + " X-габарит " + mn[0] + ".." + mx[0]);
        }

        // 3. Трансформации: объём масштабируется на sx*sy*sz, поворот его не меняет, сетка остаётся замкнутой
        Random rnd = new Random(1);
        for (int i = 0; i < 200; i++) {
            int shape = rnd.nextInt(Shapes.NAMES.length);
            Figure.Part p = new Figure.Part(shape, "t", rnd.nextDouble() * 40 - 20, rnd.nextDouble() * 40 - 20, rnd.nextDouble() * 40,
                    1 + rnd.nextDouble() * 50, 1 + rnd.nextDouble() * 50, 1 + rnd.nextDouble() * 50, 0xFF0000)
                    .rot(rnd.nextDouble() * 360 - 180, rnd.nextDouble() * 360 - 180, rnd.nextDouble() * 360 - 180);
            Mesh m = Figure.buildPart(p, 24);
            Mesh u = Figure.buildPart(new Figure.Part(shape, "u", 0, 0, 0, 1, 1, 1, 0), 24);
            ok(m.checkClosed() == null, "замкнутость после трансформации #" + i);
            double expect = u.signedVolume() * p.sx * p.sy * p.sz;
            ok(Math.abs(m.signedVolume() - expect) / expect < 1e-9, "объём после трансформации #" + i + ": " + m.signedVolume() + " vs " + expect);
        }

        // 4. Зеркало: объём тот же, центр по X отражён, сетка замкнута, центр масс отражён
        for (int i = 0; i < 100; i++) {
            int shape = rnd.nextInt(Shapes.NAMES.length);
            Figure.Part p = new Figure.Part(shape, "m", rnd.nextDouble() * 40 - 20, rnd.nextDouble() * 40 - 20, rnd.nextDouble() * 40,
                    2 + rnd.nextDouble() * 30, 2 + rnd.nextDouble() * 30, 2 + rnd.nextDouble() * 30, 0)
                    .rot(rnd.nextDouble() * 360 - 180, rnd.nextDouble() * 360 - 180, rnd.nextDouble() * 360 - 180);
            Mesh m1 = Figure.buildPart(p, 24), m2 = Figure.buildPart(p.mirrored(), 24);
            ok(m2.checkClosed() == null, "зеркало замкнуто #" + i);
            ok(Math.abs(m1.signedVolume() - m2.signedVolume()) / m1.signedVolume() < 1e-9, "зеркало: объём #" + i);
            // габариты зеркальной детали = отражённые габариты исходной по X, остальные оси те же
            double[] b1 = Figure.bounds(List.of(m1)), b2 = Figure.bounds(List.of(m2));
            ok(Math.abs(b1[0] + b2[3]) < 1e-6 && Math.abs(b1[3] + b2[0]) < 1e-6 && Math.abs(b1[1] - b2[1]) < 1e-6 && Math.abs(b1[2] - b2[2]) < 1e-6
                            && Math.abs(b1[4] - b2[4]) < 1e-6 && Math.abs(b1[5] - b2[5]) < 1e-6,
                    "зеркало: габариты #" + i + " " + Arrays.toString(b1) + " / " + Arrays.toString(b2));
        }

        // 5. Шаблоны: все детали замкнуты, экспорт читается обратно
        for (int pi = 0; pi < Figure.PRESET_NAMES.length; pi++) {
            Figure f = Figure.preset(pi);
            List<Mesh> meshes = f.build(32);
            for (Mesh m : meshes) {
                ok(m.checkClosed() == null, f.parts.size() + " " + Figure.PRESET_NAMES[pi] + "/" + m.name + " не замкнут");
                ok(m.signedVolume() > 0, Figure.PRESET_NAMES[pi] + "/" + m.name + " объём <= 0");
            }
            // сохранение/загрузка
            Figure g = Figure.fromText(f.toText());
            ok(g != null && g.parts.size() == f.parts.size(), "сохранение/загрузка " + Figure.PRESET_NAMES[pi]);
            ok(g != null && g.toText().equals(f.toText()), "текст после загрузки совпадает " + Figure.PRESET_NAMES[pi]);

            double[] b = Figure.bounds(meshes);
            System.out.printf(Locale.ROOT, "Шаблон %-9s деталей %2d, габариты %.1f x %.1f x %.1f мм%n", Figure.PRESET_NAMES[pi], f.parts.size(), b[3] - b[0], b[4] - b[1], b[5] - b[2]);

            // STL
            byte[] stl = Exporters.stl(meshes, 80);
            ByteBuffer bb = ByteBuffer.wrap(stl).order(ByteOrder.LITTLE_ENDIAN);
            int n = bb.getInt(80);
            int expectTris = 0;
            for (Mesh m : meshes) expectTris += m.triangleCount();
            ok(n == expectTris && stl.length == 84 + 50 * n, "STL размер " + pi);
            double minz = 1e9, maxz = -1e9, minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9, vol = 0;
            boolean nanFound = false, normalsOk = true;
            for (int i = 0; i < n; i++) {
                int o = 84 + 50 * i;
                float[] f12 = new float[12];
                for (int k = 0; k < 12; k++) f12[k] = bb.getFloat(o + 4 * k);
                for (float fv : f12) if (Float.isNaN(fv) || Float.isInfinite(fv)) nanFound = true;
                double ux = f12[6] - f12[3], uy = f12[7] - f12[4], uz = f12[8] - f12[5];
                double wx = f12[9] - f12[3], wy = f12[10] - f12[4], wz = f12[11] - f12[5];
                double cx = uy * wz - uz * wy, cy = uz * wx - ux * wz, cz = ux * wy - uy * wx;
                if (cx * f12[0] + cy * f12[1] + cz * f12[2] < -1e-3 * Math.sqrt(cx * cx + cy * cy + cz * cz)) normalsOk = false;
                for (int k = 0; k < 3; k++) {
                    double x = f12[3 + 3 * k], y = f12[4 + 3 * k], z = f12[5 + 3 * k];
                    minx = Math.min(minx, x); maxx = Math.max(maxx, x);
                    miny = Math.min(miny, y); maxy = Math.max(maxy, y);
                    minz = Math.min(minz, z); maxz = Math.max(maxz, z);
                }
            }
            ok(!nanFound, "STL NaN/Inf " + pi);
            ok(normalsOk, "STL нормали согласованы с обходом " + pi);
            ok(Math.abs(minz) < 1e-4 && Math.abs(maxz - 80) < 1e-3, "STL: низ на столе и высота 80 мм: " + minz + ".." + maxz);
            ok(Math.abs(minx + maxx) < 1e-3 && Math.abs(miny + maxy) < 1e-3, "STL: центр по XY в нуле");

            // 3MF
            byte[] mf = Exporters.threeMf(meshes, 80, Figure.PRESET_NAMES[pi]);
            Map<String, byte[]> files = new HashMap<>();
            try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(mf))) {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) files.put(e.getName(), zin.readAllBytes());
            }
            ok(files.containsKey("[Content_Types].xml") && files.containsKey("_rels/.rels") && files.containsKey("3D/3dmodel.model"), "3MF состав архива " + pi);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setNamespaceAware(true);
            Document doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(files.get("3D/3dmodel.model")));
            for (String name : new String[]{"[Content_Types].xml", "_rels/.rels"})
                dbf.newDocumentBuilder().parse(new ByteArrayInputStream(files.get(name)));
            NodeList objs = doc.getElementsByTagName("object");
            Set<String> ids = new HashSet<>();
            int meshObjs = 0, comps = 0, trisTotal = 0;
            double zmin = 1e9, zmax = -1e9;
            for (int i = 0; i < objs.getLength(); i++) {
                Element o = (Element) objs.item(i);
                ok(ids.add(o.getAttribute("id")), "3MF id уникален");
                NodeList vs = o.getElementsByTagName("vertex"), ts = o.getElementsByTagName("triangle");
                if (vs.getLength() > 0) {
                    meshObjs++;
                    trisTotal += ts.getLength();
                    for (int k = 0; k < vs.getLength(); k++) {
                        double z = Double.parseDouble(((Element) vs.item(k)).getAttribute("z"));
                        zmin = Math.min(zmin, z); zmax = Math.max(zmax, z);
                    }
                    for (int k = 0; k < ts.getLength(); k++) {
                        Element t = (Element) ts.item(k);
                        for (String at : new String[]{"v1", "v2", "v3"}) {
                            int idx = Integer.parseInt(t.getAttribute(at));
                            ok(idx >= 0 && idx < vs.getLength(), "3MF индекс вершины в диапазоне");
                        }
                    }
                } else comps += o.getElementsByTagName("component").getLength();
            }
            ok(meshObjs == meshes.size() && comps == meshes.size() && trisTotal == expectTris, "3MF: объекты/компоненты/треугольники " + pi);
            ok(Math.abs(zmin) < 1e-3 && Math.abs(zmax - 80) < 1e-3, "3MF: Z-диапазон " + zmin + ".." + zmax);
            NodeList comp = doc.getElementsByTagName("component");
            for (int i = 0; i < comp.getLength(); i++) ok(ids.contains(((Element) comp.item(i)).getAttribute("objectid")), "3MF ссылка компонента");
            NodeList items = doc.getElementsByTagName("item");
            ok(items.getLength() == 1 && ids.contains(((Element) items.item(0)).getAttribute("objectid")), "3MF build item");
            System.out.printf(Locale.ROOT, "   STL %d КБ, 3MF %d КБ, треугольников %d%n", stl.length / 1024, mf.length / 1024, expectTris);
        }

        // 5b. Проекция: отсечение граней, выбор детали касанием, порядок по глубине
        {
            Figure.Part cube = new Figure.Part(Shapes.BOX, "куб", 0, 0, 0, 20, 20, 20, 0xFFFFFF);
            Projector.Frame f0 = Projector.render(List.of(Figure.buildPart(cube, 8)), -1, 0, 0, 1, 400, 400);
            ok(f0.count == 2, "куб прямо спереди: видна одна грань (2 треугольника), а не " + f0.count);
            Projector.Frame f30 = Projector.render(List.of(Figure.buildPart(cube, 8)), -1, 0, 30, 1, 400, 400);
            ok(f30.count == 4, "куб сверху под 30°: видны 2 грани (4 треугольника), а не " + f30.count);
            Projector.Frame f45 = Projector.render(List.of(Figure.buildPart(cube, 8)), -1, 45, 30, 1, 400, 400);
            ok(f45.count == 6, "куб по диагонали: видны 3 грани (6 треугольников), а не " + f45.count);
            // верхняя грань светлее боковой (свет сверху-слева-спереди)
            int bTop = 0, bSide = 0;
            for (int i = 0; i < f30.count; i++) {
                float cy = (f30.xy[i * 6 + 1] + f30.xy[i * 6 + 3] + f30.xy[i * 6 + 5]) / 3;
                int g = (f30.argb[i] >> 8) & 255;
                if (cy < 200) bTop = Math.max(bTop, g); else bSide = Math.max(bSide, g);
            }
            ok(bTop > bSide, "верхняя грань светлее передней: " + bTop + " vs " + bSide);
            for (int i = 0; i < f30.count; i++) ok((f30.argb[i] >>> 24) == 255, "альфа непрозрачна");

            // две детали друг за другом: ближняя должна выбираться касанием
            Figure.Part near = new Figure.Part(Shapes.BOX, "ближний", 0, -30, 0, 20, 20, 20, 0xFF0000);
            Figure.Part far = new Figure.Part(Shapes.BOX, "дальний", 0, 30, 0, 20, 20, 20, 0x00FF00);
            List<Mesh> two = List.of(Figure.buildPart(near, 8), Figure.buildPart(far, 8));
            // камера с -Y (yaw=0): ближний — индекс 0
            Projector.Frame fa = Projector.render(two, -1, 0, 0, 1, 400, 400);
            ok(fa.pick(200, 200) == 0, "выбор ближней детали (камера спереди): " + fa.pick(200, 200));
            Projector.Frame fb = Projector.render(two, -1, 180, 0, 1, 400, 400);
            ok(fb.pick(200, 200) == 1, "выбор ближней детали (камера сзади): " + fb.pick(200, 200));
            ok(fa.pick(5, 5) == -1, "касание мимо фигурки возвращает -1");
            // подсветка выбранной детали меняет цвет
            Projector.Frame fs = Projector.render(two, 1, 180, 0, 1, 400, 400);
            ok(fs.argb[fs.count - 1] != fb.argb[fb.count - 1], "подсветка выбранной детали");

            // шаблоны с разных ракурсов: ничего не падает, числа конечные, кадр не пустой
            for (int pi = 0; pi < Figure.PRESET_NAMES.length; pi++) {
                List<Mesh> ms = Figure.preset(pi).build(16);
                for (double yaw = 0; yaw < 360; yaw += 45) for (double pit : new double[]{-89, -20, 0, 35, 89}) {
                    Projector.Frame fr = Projector.render(ms, 0, yaw, pit, 1.5, 360, 480);
                    boolean fin = fr.count > 0;
                    for (float q : fr.xy) if (Float.isNaN(q) || Float.isInfinite(q)) fin = false;
                    for (float q : fr.grid) if (Float.isNaN(q) || Float.isInfinite(q)) fin = false;
                    ok(fin, "кадр " + Figure.PRESET_NAMES[pi] + " yaw=" + yaw + " pitch=" + pit);
                }
            }
            // скорость кадра на самой тяжёлой фигурке
            List<Mesh> heavy = Figure.preset(1).build(16);
            long t0 = System.nanoTime();
            int tris = 0;
            for (int i = 0; i < 200; i++) tris = Projector.render(heavy, 0, i * 3, 25, 1, 400, 600).count;
            double ms = (System.nanoTime() - t0) / 1e6 / 200;
            System.out.printf(Locale.ROOT, "Кадр превью (Мишка, 16 сегм.): %.2f мс, видимых треугольников %d%n", ms, tris);
        }

        // 6. Устойчивость: пустая фигура и некорректный текст
        ok(Exporters.stl(new ArrayList<>(), 60).length == 84, "пустой STL");
        ok(Figure.fromText("мусор") == null && Figure.fromText(null) == null && Figure.fromText("FIG1\n1|2|3") == null, "некорректный текст сохранения");

        System.out.println(checks + " проверок, провалов: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
